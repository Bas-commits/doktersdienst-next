(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_context__.s([
    "connect",
    ()=>connect,
    "setHooks",
    ()=>setHooks,
    "subscribeToUpdate",
    ()=>subscribeToUpdate
]);
function connect({ addMessageListener, sendMessage, onUpdateError = console.error }) {
    addMessageListener((msg)=>{
        switch(msg.type){
            case 'turbopack-connected':
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn('[Fast Refresh] performing full reload\n\n' + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + 'You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n' + 'Consider migrating the non-React component export to a separate file and importing it into both files.\n\n' + 'It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n' + 'Fast Refresh requires at least one parent function component in your React tree.');
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error('A separate HMR handler was already registered');
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: ([chunkPath, callback])=>{
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: 'turbopack-subscribe',
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: 'turbopack-unsubscribe',
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: 'ChunkListUpdate',
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted' || updateA.type === 'deleted' && updateB.type === 'added') {
        return undefined;
    }
    if (updateA.type === 'partial') {
        invariant(updateA.instruction, 'Partial updates are unsupported');
    }
    if (updateB.type === 'partial') {
        invariant(updateB.instruction, 'Partial updates are unsupported');
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: 'EcmascriptMergedUpdate',
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted') {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === 'deleted' && updateB.type === 'added') {
        const added = [];
        const deleted = [];
        const deletedModules = new Set(updateA.modules ?? []);
        const addedModules = new Set(updateB.modules ?? []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: 'partial',
            added,
            deleted
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'partial') {
        const added = new Set([
            ...updateA.added ?? [],
            ...updateB.added ?? []
        ]);
        const deleted = new Set([
            ...updateA.deleted ?? [],
            ...updateB.deleted ?? []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: 'partial',
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === 'added' && updateB.type === 'partial') {
        const modules = new Set([
            ...updateA.modules ?? [],
            ...updateB.added ?? []
        ]);
        for (const moduleId of updateB.deleted ?? []){
            modules.delete(moduleId);
        }
        return {
            type: 'added',
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'deleted') {
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set(updateB.modules ?? []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: 'deleted',
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error(`Invariant: ${message}`);
}
const CRITICAL = [
    'bug',
    'error',
    'fatal'
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    'bug',
    'fatal',
    'error',
    'warning',
    'info',
    'log'
];
const CATEGORY_ORDER = [
    'parse',
    'resolve',
    'code generation',
    'rendering',
    'typescript',
    'other'
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case 'issues':
            break;
        case 'partial':
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkListPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkListPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === 'notFound') {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}),
"[project]/src/lib/auth-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authClient",
    ()=>authClient,
    "signIn",
    ()=>signIn,
    "signOut",
    ()=>signOut,
    "signUp",
    ()=>signUp,
    "useSession",
    ()=>useSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/better-auth/dist/client/react/index.mjs [client] (ecmascript) <locals>");
;
// In the browser always use the current origin so sign-in fetches hit the same host
// (avoids "Failed to fetch" when NEXT_PUBLIC_BETTER_AUTH_URL points to ngrok/tunnel that is down).
// Server-side (SSR) falls back to env or localhost.
const baseURL = ("TURBOPACK compile-time truthy", 1) ? window.location.origin : "TURBOPACK unreachable";
const authClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$better$2d$auth$2f$dist$2f$client$2f$react$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAuthClient"])({
    baseURL
});
const { useSession, signIn, signUp, signOut } = authClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/utils.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/card.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardAction",
    ()=>CardAction,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [client] (ecmascript)");
;
;
function Card({ className, size = "default", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card",
        "data-size": size,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("group/card flex flex-col gap-4 overflow-hidden rounded-xl bg-card py-4 text-sm text-card-foreground ring-1 ring-foreground/10 has-data-[slot=card-footer]:pb-0 has-[>img:first-child]:pt-0 data-[size=sm]:gap-3 data-[size=sm]:py-3 data-[size=sm]:has-data-[slot=card-footer]:pb-0 *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = Card;
function CardHeader({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("group/card-header @container/card-header grid auto-rows-min items-start gap-1 rounded-t-xl px-4 group-data-[size=sm]/card:px-3 has-data-[slot=card-action]:grid-cols-[1fr_auto] has-data-[slot=card-description]:grid-rows-[auto_auto] [.border-b]:pb-4 group-data-[size=sm]/card:[.border-b]:pb-3", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c1 = CardHeader;
function CardTitle({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("text-base leading-snug font-medium group-data-[size=sm]/card:text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
_c2 = CardTitle;
function CardDescription({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_c3 = CardDescription;
function CardAction({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-action",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("col-start-2 row-span-2 row-start-1 self-start justify-self-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_c4 = CardAction;
function CardContent({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("px-4 group-data-[size=sm]/card:px-3", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
_c5 = CardContent;
function CardFooter({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center rounded-b-xl border-t bg-muted/50 p-4 group-data-[size=sm]/card:p-3", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_c6 = CardFooter;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6;
__turbopack_context__.k.register(_c, "Card");
__turbopack_context__.k.register(_c1, "CardHeader");
__turbopack_context__.k.register(_c2, "CardTitle");
__turbopack_context__.k.register(_c3, "CardDescription");
__turbopack_context__.k.register(_c4, "CardAction");
__turbopack_context__.k.register(_c5, "CardContent");
__turbopack_context__.k.register(_c6, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/types/voorkeuren.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Types for the get-indicate-preference API and voorkeuren calendar UI.
 * Aligned with backend PreferenceController and voorkeuren.js.
 */ __turbopack_context__.s([
    "CHIP_DEFINITIONS",
    ()=>CHIP_DEFINITIONS,
    "buildPreferencePayload",
    ()=>buildPreferencePayload,
    "formatDateDDMMYYYY",
    ()=>formatDateDDMMYYYY,
    "getChipByCode",
    ()=>getChipByCode,
    "shiftKey",
    ()=>shiftKey,
    "shiftKeyFromBlock",
    ()=>shiftKeyFromBlock
]);
const CHIP_DEFINITIONS = [
    {
        code: '1014',
        label: 'Weghalen',
        selectorIconPath: '',
        chipIconPath: ''
    },
    {
        code: '3',
        label: 'Liever wel',
        selectorIconPath: '/images/icons/check.svg',
        chipIconPath: '/images/icons/check.svg'
    },
    {
        code: '2',
        label: 'Liever niet',
        selectorIconPath: '/images/icons/cross.svg',
        chipIconPath: '/images/icons/cross.svg'
    },
    {
        code: '9',
        label: 'Vakantie',
        selectorIconPath: '/images/icons/holliday.svg',
        chipIconPath: '/images/icons/holliday-bg.svg'
    },
    {
        code: '10',
        label: 'Nascholing',
        selectorIconPath: '/images/icons/education.svg',
        chipIconPath: '/images/icons/education-bg.svg'
    },
    {
        code: '5001',
        label: 'FTE',
        selectorIconPath: '/images/icons/FTE.svg',
        chipIconPath: '/images/icons/FTE-bg.svg'
    }
];
function shiftKey(currentDate, van, tot, doctorId) {
    return `${currentDate}_${van}_${tot}_${doctorId}`;
}
function shiftKeyFromBlock(block) {
    return `${block.currentDate}_${block.van}_${block.tot}_${block.id}`;
}
function getChipByCode(code) {
    return CHIP_DEFINITIONS.find((c)=>c.code === code);
}
function formatDateDDMMYYYY(day, month, year) {
    const d = Number(day);
    const m = Number(month);
    const y = Number(year);
    return (d < 10 ? `0${d}` : String(d)) + '-' + (m < 10 ? `0${m}` : String(m)) + '-' + String(y);
}
function buildPreferencePayload(chips, pendingInsert, pendingDelete, groupId, currentUserDoctorId) {
    const insertItems = [];
    pendingInsert.forEach((code, key)=>{
        const chip = chips.find((c)=>shiftKey(c.current_date, c.van, c.tot, c.IDdeelnemer) === key);
        if (!chip) return;
        insertItems.push({
            doctorid: currentUserDoctorId,
            current_date: chip.current_date,
            next_date: chip.next_date,
            van: chip.van,
            tot: chip.tot,
            date: formatDateDDMMYYYY(chip.day, chip.month, chip.year),
            day: Number(chip.day),
            month: Number(chip.month),
            year: Number(chip.year),
            description: '',
            code,
            GroupId: groupId
        });
    });
    const deleteItems = [];
    pendingDelete.forEach((key)=>{
        const chip = chips.find((c)=>shiftKey(c.current_date, c.van, c.tot, c.IDdeelnemer) === key);
        if (!chip) return;
        deleteItems.push({
            doctorid: currentUserDoctorId,
            current_date: chip.current_date,
            next_date: chip.next_date,
            van: chip.van,
            tot: chip.tot,
            date: formatDateDDMMYYYY(chip.day, chip.month, chip.year),
            day: Number(chip.day),
            month: Number(chip.month),
            year: Number(chip.year),
            description: '',
            code: '1014',
            GroupId: groupId
        });
    });
    return {
        insert: insertItems,
        delete: deleteItems
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/calendarUtils.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MONTH_LONG",
    ()=>MONTH_LONG,
    "MONTH_SHORT",
    ()=>MONTH_SHORT,
    "WEEKDAY_LABELS",
    ()=>WEEKDAY_LABELS,
    "getDateRangeOfWeek",
    ()=>getDateRangeOfWeek,
    "getWeek",
    ()=>getWeek,
    "getWeekNumber",
    ()=>getWeekNumber,
    "monthWeekCount",
    ()=>monthWeekCount
]);
function getWeek(date) {
    const target = new Date(date.valueOf());
    const dayNr = (date.getDay() + 6) % 7;
    target.setDate(target.getDate() - dayNr + 3);
    const firstThursday = target.valueOf();
    target.setMonth(0, 1);
    if (target.getDay() !== 4) {
        target.setMonth(0, 1 + (4 - target.getDay() + 7) % 7);
    }
    return 1 + Math.ceil((firstThursday - target.getTime()) / 604800000);
}
function monthWeekCount(year, month) {
    const firstOfMonth = new Date(year, month, 1);
    const lastOfMonth = new Date(year, month + 1, 0);
    const lastDate = lastOfMonth.getDate();
    const offset = (firstOfMonth.getDay() + 6) % 7; // Monday = 0
    return Math.ceil((lastDate + offset) / 7);
}
function getDateRangeOfWeek(weekNo, currentYear) {
    const result = [];
    const d1 = new Date();
    d1.setFullYear(currentYear);
    const numOfdaysPastSinceLastMonday = d1.getDay() - 1;
    d1.setDate(d1.getDate() - numOfdaysPastSinceLastMonday);
    const weekNoToday = getWeek(d1);
    const weeksInTheFuture = weekNo - weekNoToday;
    d1.setDate(d1.getDate() + 7 * weeksInTheFuture);
    for(let i = 0; i < 7; i++){
        const m = d1.getMonth() + 1;
        const day = d1.getDate();
        const y = d1.getFullYear();
        const getFullDate = y + '-' + (m < 10 ? '0' + m : String(m)) + '-' + (day < 10 ? '0' + day : String(day));
        const DateDDMMYYYY = (day < 10 ? '0' + day : String(day)) + '-' + (m < 10 ? '0' + m : String(m)) + '-' + y;
        result.push({
            Date: getFullDate,
            DateDDMMYYYY,
            Day: day,
            Month: d1.getMonth(),
            Year: y
        });
        d1.setDate(d1.getDate() + 1);
    }
    return result;
}
function getWeekNumber(dateString) {
    const parts = dateString.split(/[-/]/).map(Number);
    const y = parts[0];
    const m = parts[1] ?? 1;
    const d = parts[2] ?? 1;
    const date = new Date(y, m - 1, d);
    const week = getWeek(date);
    const dayNr = (date.getDay() + 6) % 7;
    const thursday = new Date(date);
    thursday.setDate(date.getDate() - dayNr + 3);
    const year = thursday.getFullYear();
    return {
        year,
        week
    };
}
const MONTH_SHORT = [
    'jan',
    'feb',
    'mrt',
    'apr',
    'mei',
    'jun',
    'jul',
    'aug',
    'sep',
    'okt',
    'nov',
    'dec'
];
const MONTH_LONG = [
    'Januari',
    'Februari',
    'Maart',
    'April',
    'Mei',
    'Juni',
    'Juli',
    'Augustus',
    'September',
    'Oktober',
    'November',
    'December'
];
const WEEKDAY_LABELS = [
    'Maandag',
    'Dinsdag',
    'Woensdag',
    'Donderdag',
    'Vrijdag',
    'Zaterdag',
    'Zondag'
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ShiftBlock/ShiftBlock.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShiftBlock",
    ()=>ShiftBlock,
    "isShiftActiveAt",
    ()=>isShiftActiveAt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/briefcase.js [client] (ecmascript) <export default as Briefcase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/graduation-cap.js [client] (ecmascript) <export default as GraduationCap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tree$2d$palm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TreePalm$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/tree-palm.js [client] (ecmascript) <export default as TreePalm>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
;
;
function isShiftActiveAt(block, when) {
    try {
        // Dates are stored as "Y-m-d H:i:s"; parse as full datetime.
        const startStr = String(block.currentDate).replace(' ', 'T');
        const endStr = String(block.nextDate).replace(' ', 'T');
        const start = new Date(startStr);
        const end = new Date(endStr);
        const startMs = start.getTime();
        const endMs = end.getTime();
        if (Number.isNaN(startMs) || Number.isNaN(endMs)) {
            return false;
        }
        const t = when.getTime();
        return t >= startMs && t <= endMs;
    } catch  {
        return false;
    }
}
function ShiftBlock({ block, day, month, year, containerWidth, onClick, activeSection, showEmptyTopStripBorder, showEmptyBottomStripBorder, hideTopStrip, hideBottomStrip, pendingDoctor, pendingDoctorTop, pendingDoctorBottom, onSectionClick, pendingRemoveSections, onDelete, segmentStartTime, segmentEndTime, continuesFromPrev, continuesToNext, preferenceChip, middleHeight, disableActiveHighlight }) {
    _s();
    const [now, setNow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        "ShiftBlock.useState": ()=>new Date()
    }["ShiftBlock.useState"]);
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ShiftBlock.useEffect": ()=>{
            const id = setInterval({
                "ShiftBlock.useEffect.id": ()=>setNow(new Date())
            }["ShiftBlock.useEffect.id"], 60_000);
            return ({
                "ShiftBlock.useEffect": ()=>clearInterval(id)
            })["ShiftBlock.useEffect"];
        }
    }["ShiftBlock.useEffect"], []);
    const isActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ShiftBlock.useMemo[isActive]": ()=>!disableActiveHighlight && isShiftActiveAt(block, now)
    }["ShiftBlock.useMemo[isActive]"], [
        block,
        now,
        disableActiveHighlight
    ]);
    const doctorId = block.middle?.id ?? 0;
    const achterw = block.top?.id ?? 0;
    const extra = block.bottom?.id ?? 0;
    const startDate = new Date(block.currentDate);
    const endDate = new Date(block.nextDate);
    const startIsWeekend = startDate.getDay() === 0 || startDate.getDay() === 6;
    const endIsWeekend = endDate.getDay() === 0 || endDate.getDay() === 6;
    const cellDate = new Date(year, month, day);
    const isMonday = cellDate.getDay() === 1;
    const totalMinutesInDay = 24 * 60;
    const parseTimeToMinutes = (time)=>{
        const [h, m] = time.split(':').map((part)=>Number(part));
        if (Number.isNaN(h) || Number.isNaN(m)) return 0;
        const minutes = h * 60 + m;
        if (minutes < 0) return 0;
        if (minutes > totalMinutesInDay) return totalMinutesInDay;
        return minutes;
    };
    const useSegment = segmentStartTime != null && segmentEndTime != null && segmentStartTime !== '' && segmentEndTime !== '';
    const startMinutes = useSegment ? parseTimeToMinutes(segmentStartTime) : parseTimeToMinutes(block.startTime);
    const endMinutes = useSegment ? parseTimeToMinutes(segmentEndTime) : parseTimeToMinutes(block.endTime);
    const sameDay = endMinutes >= startMinutes;
    const durationMinutes = sameDay ? endMinutes - startMinutes : totalMinutesInDay - startMinutes + endMinutes;
    const usePixelLayout = containerWidth != null && Number.isFinite(containerWidth) && containerWidth > 0;
    const safeContainerWidth = usePixelLayout ? containerWidth : 1;
    const leftPx = startMinutes / totalMinutesInDay * safeContainerWidth;
    const widthPx = durationMinutes / totalMinutesInDay * safeContainerWidth;
    const leftPercent = startMinutes / totalMinutesInDay * 100;
    const widthPercent = durationMinutes / totalMinutesInDay * 100;
    let cssInline = {};
    if (doctorId !== 0) {
        if (!isMonday && startIsWeekend && !endIsWeekend) {
            cssInline = {
                borderRightStyle: 'none'
            };
        } else if (isMonday && startIsWeekend) {
            cssInline = {
                borderLeftStyle: 'none'
            };
        }
    } else {
        if (!isMonday && startIsWeekend && !endIsWeekend) {
            cssInline = {
                borderRightStyle: 'none'
            };
        } else if (isMonday && startIsWeekend) {
            cssInline = {
                borderLeftStyle: 'none'
            };
        }
    }
    const isSunday = cellDate.getDay() === 0;
    // Flags for applying edge gradients when a segment continues across rows (Sunday→Monday).
    const hasLeftEdgeGradient = !!continuesFromPrev && isMonday;
    const hasRightEdgeGradient = !!continuesToNext && isSunday;
    // Compute rounded corner classes based on continuity across midnight
    const middleRoundedClass = continuesFromPrev && continuesToNext ? '' : continuesFromPrev ? 'rounded-r-[3px]' : continuesToNext ? 'rounded-l-[3px]' : 'rounded-[3px]';
    const stripRoundedClass = continuesFromPrev && continuesToNext ? '' : continuesFromPrev ? 'rounded-r-[3px]' : continuesToNext ? 'rounded-l-[3px]' : 'rounded-[3px]';
    if (continuesFromPrev) {
        // Seamless join on the left; extra visual cue handled via gradient flags above.
        cssInline = {
            ...cssInline,
            borderLeftStyle: 'none'
        };
    }
    if (continuesToNext) {
        // Seamless join on the right; extra visual cue handled via gradient flags above.
        cssInline = {
            ...cssInline,
            borderRightStyle: 'none'
        };
    }
    const achterwDoc = block.top ?? null;
    const extraDoc = block.bottom ?? null;
    const mainDoc = block.middle ?? null;
    const displayShortName = (mainDoc?.shortName ?? '').trim() || (mainDoc?.name ?? '').slice(0, 3).toUpperCase() || (doctorId ? `#${doctorId}` : '');
    const displayName = (mainDoc?.name ?? '').trim() || (doctorId ? `Doctor ${doctorId}` : '');
    const mainColor = mainDoc?.color ?? (doctorId ? '#c686fd' : 'transparent');
    const isUnassignedSlot = !block.middle;
    const showPendingDoctor = isUnassignedSlot && pendingDoctor != null;
    if (isUnassignedSlot) {
        // Type 1 = shift slot: gray outline, or pending doctor color/initials when assigned in planner
        cssInline = {
            ...cssInline,
            backgroundColor: showPendingDoctor ? pendingDoctor.color : 'transparent',
            border: showPendingDoctor ? undefined : '1px solid #dcdcdc',
            minHeight: 42
        };
    } else {
        cssInline = {
            ...cssInline,
            backgroundColor: mainColor
        };
    }
    if (!isUnassignedSlot && (doctorId || achterw || extra)) {
        cssInline = {
            ...cssInline,
            minHeight: middleHeight ?? 42
        };
    }
    // Apply linear gradients on the left/right edges when the segment continues across rows.
    if (!isUnassignedSlot && (hasLeftEdgeGradient || hasRightEdgeGradient) && mainColor && mainColor !== 'transparent') {
        const backgroundColor = cssInline.backgroundColor || mainColor;
        const gradientLayers = [];
        const positions = [];
        const sizes = [];
        if (hasLeftEdgeGradient) {
            gradientLayers.push(`linear-gradient(to left, ${backgroundColor}, #ffffff)`);
            positions.push('left top');
            sizes.push('8px 100%');
        }
        if (hasRightEdgeGradient) {
            gradientLayers.push(`linear-gradient(to right, ${backgroundColor}, #ffffff)`);
            positions.push('right top');
            sizes.push('8px 100%');
        }
        const existingImage = cssInline.backgroundImage;
        const mergedImages = [
            gradientLayers.join(', '),
            existingImage
        ].filter(Boolean).join(', ');
        cssInline = {
            ...cssInline,
            backgroundColor,
            backgroundImage: mergedImages || undefined,
            backgroundRepeat: 'no-repeat',
            backgroundPosition: positions.join(', ') || undefined,
            backgroundSize: sizes.join(', ') || undefined
        };
    }
    // When onSectionClick is set, each stripe is clickable by its show prop; otherwise use activeSection + onClick.
    const useSectionClick = onSectionClick != null;
    const topStripClickable = useSectionClick ? !!showEmptyTopStripBorder : activeSection === 'top';
    const middleStripClickable = useSectionClick ? true : activeSection === undefined || activeSection === 'middle';
    const bottomStripClickable = useSectionClick ? !!showEmptyBottomStripBorder : activeSection === 'bottom';
    const topHasClick = topStripClickable && (useSectionClick ? onSectionClick : onClick);
    const middleHasClick = middleStripClickable && (useSectionClick ? onSectionClick : onClick);
    const bottomHasClick = bottomStripClickable && (useSectionClick ? onSectionClick : onClick);
    const topPending = achterw === 0 && pendingDoctorTop;
    const bottomPending = extra === 0 && pendingDoctorBottom;
    const dimTop = pendingRemoveSections?.has('top');
    const dimMiddle = pendingRemoveSections?.has('middle');
    const dimBottom = pendingRemoveSections?.has('bottom');
    /** Filled preference styles: block background + Lucide icon (Liever wel, Liever niet, Vakantie, Nascholing). */ const preferenceFill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ShiftBlock.useMemo[preferenceFill]": ()=>{
            if (!preferenceChip) return null;
            const map = {
                '3': {
                    backgroundColor: '#22c55e',
                    Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"],
                    iconColor: 'white'
                },
                '2': {
                    backgroundColor: '#eab308',
                    Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"],
                    iconColor: 'white'
                },
                '9': {
                    backgroundColor: '#ef4444',
                    Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tree$2d$palm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TreePalm$3e$__["TreePalm"],
                    iconColor: 'white'
                },
                '10': {
                    backgroundColor: '#a855f7',
                    Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__["GraduationCap"],
                    iconColor: 'white'
                },
                '5001': {
                    backgroundColor: '#64748b',
                    Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__["Briefcase"],
                    iconColor: 'white'
                }
            };
            return map[preferenceChip.code] ?? null;
        }
    }["ShiftBlock.useMemo[preferenceFill]"], [
        preferenceChip
    ]);
    const showPreferenceFill = preferenceFill != null;
    const showPreferenceBadge = preferenceChip != null && !showPreferenceFill;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "absolute",
        "data-box-type": "morning",
        "data-active-shift": isActive ? 'true' : undefined,
        onMouseEnter: ()=>setIsHovered(true),
        onMouseLeave: ()=>setIsHovered(false),
        style: {
            top: '50%',
            // Extend 1px on connecting sides to visually cover the 1px day-column divider border
            width: usePixelLayout ? `${widthPx + (continuesFromPrev ? 1 : 0) + (continuesToNext ? 1 : 0)}px` : continuesFromPrev || continuesToNext ? `calc(${widthPercent}% + ${(continuesFromPrev ? 1 : 0) + (continuesToNext ? 1 : 0)}px)` : `${widthPercent}%`,
            left: usePixelLayout ? `${leftPx + (continuesFromPrev ? -1 : 0)}px` : continuesFromPrev ? `calc(${leftPercent}% - 1px)` : `${leftPercent}%`,
            transform: 'translateY(-50%)',
            zIndex: isHovered ? 9999 : continuesFromPrev || continuesToNext ? 1 : undefined
        },
        children: [
            onDelete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "shift-block-delete absolute top-0.5 right-0.5 z-10 flex h-5 w-5 items-center justify-center rounded bg-red-500/90 text-white hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400",
                onClick: (e)=>{
                    e.stopPropagation();
                    onDelete();
                },
                "aria-label": "Shift verwijderen",
                "data-testid": "shift-block-delete",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                    className: "h-3 w-3",
                    "aria-hidden": true
                }, void 0, false, {
                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                    lineNumber: 371,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                lineNumber: 361,
                columnNumber: 9
            }, this),
            !hideTopStrip && (achterw === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `h-3 ${stripRoundedClass} text-[10px] text-center leading-3 text-white font-bold tracking-[0.5px] mb-1.5${topStripClickable ? ' cursor-pointer' : ''}`,
                "data-doctor": "111",
                "data-testid": "shift-block-top",
                style: {
                    background: topPending ? pendingDoctorTop.color : 'transparent',
                    border: achterwDoc ? undefined : 'solid 1px #dcdcdc',
                    cursor: topHasClick ? 'pointer' : undefined,
                    opacity: dimTop ? 0.35 : undefined
                },
                onClick: topHasClick ? (e)=>useSectionClick ? onSectionClick('top', e) : onClick(e) : undefined,
                children: topPending ? pendingDoctorTop.shortName : null
            }, void 0, false, {
                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                lineNumber: 376,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `h-3 ${stripRoundedClass} text-[10px] text-center leading-3 text-white font-bold tracking-[0.5px] mb-1.5${topStripClickable ? ' cursor-pointer' : ''}`,
                "data-doctor": achterw,
                "data-testid": "shift-block-top",
                style: {
                    background: achterwDoc?.color ?? 'transparent',
                    cursor: topHasClick ? 'pointer' : undefined,
                    opacity: dimTop ? 0.35 : undefined
                },
                onClick: topHasClick ? (e)=>useSectionClick ? onSectionClick('top', e) : onClick(e) : undefined,
                children: (achterwDoc?.shortName ?? '').trim() || (achterwDoc?.name ?? '').slice(0, 3).toUpperCase() || `#${achterw}`
            }, void 0, false, {
                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                lineNumber: 391,
                columnNumber: 11
            }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "group",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `flex mt-1 mb-1 items-center justify-between relative border border-[#a0a0a0] ${middleRoundedClass} ${doctorId ? 'active-day' : ''} ${showPreferenceFill ? 'justify-center' : ''}`,
                        "data-testid": "shift-block-middle",
                        "data-doctor": doctorId,
                        "data-current-date": block.currentDate,
                        "data-next-date": block.nextDate,
                        "data-date": day,
                        "data-month": month,
                        "data-year": year,
                        "data-morning": doctorId,
                        style: {
                            height: middleHeight ?? 42,
                            ...cssInline,
                            ...showPreferenceFill ? {
                                backgroundColor: preferenceFill.backgroundColor,
                                backgroundImage: undefined,
                                border: '1px solid rgba(0,0,0,0.15)'
                            } : {},
                            // Re-apply continuation overrides: the `border` shorthand above resets borderLeft/RightStyle,
                            // so we must restore 'none' afterwards for multi-day blocks to connect seamlessly.
                            ...continuesFromPrev ? {
                                borderLeftStyle: 'none'
                            } : {},
                            ...continuesToNext ? {
                                borderRightStyle: 'none'
                            } : {},
                            ...middleHasClick ? {
                                cursor: 'pointer'
                            } : {},
                            ...dimMiddle ? {
                                opacity: 0.35
                            } : {},
                            ...isActive ? {
                                borderColor: '#dc2626',
                                borderTopWidth: '3px',
                                borderBottomWidth: '3px',
                                borderLeftWidth: continuesFromPrev ? '0' : '3px',
                                borderRightWidth: continuesToNext ? '0' : '3px',
                                zIndex: 1
                            } : {}
                        },
                        onClick: middleHasClick ? (e)=>useSectionClick ? onSectionClick('middle', e) : onClick(e) : undefined,
                        title: preferenceChip?.label,
                        children: [
                            showPreferenceFill ? (()=>{
                                const { Icon } = preferenceFill;
                                return displayShortName ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-white text-[8px] font-bold leading-none pl-0.5",
                                            children: displayShortName
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                            lineNumber: 450,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                            className: "h-3 w-3 shrink-0 text-white pr-0.5",
                                            "aria-hidden": true
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                            lineNumber: 451,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                    className: "h-5 w-5 shrink-0 text-white",
                                    "aria-hidden": true
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                    lineNumber: 454,
                                    columnNumber: 15
                                }, this);
                            })() : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `rotate-180 whitespace-nowrap text-sm font-mono ${doctorId ? 'text-white' : 'text-[#a0a0a0]'}`,
                                        style: {
                                            writingMode: 'vertical-rl'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                        lineNumber: 458,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-white text-[10px] font-semibold tracking-[0.5px] break-words leading-[15px]",
                                        children: showPendingDoctor ? pendingDoctor.shortName : displayShortName
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                        lineNumber: 462,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `rotate-180 whitespace-nowrap text-sm font-mono ${doctorId ? 'text-white' : 'text-[#a0a0a0]'}`,
                                        style: {
                                            writingMode: 'vertical-rl'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                        lineNumber: 465,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true),
                            showPreferenceBadge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "absolute bottom-0.5 right-0.5 flex h-4 w-4 items-center justify-center rounded bg-black/30 pointer-events-none",
                                title: preferenceChip.label,
                                "aria-hidden": true,
                                children: preferenceChip.chipIconPath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: preferenceChip.chipIconPath,
                                    alt: "",
                                    className: "h-3 w-3 object-contain"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                    lineNumber: 478,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                    className: "h-3 w-3 text-white",
                                    "aria-hidden": true
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                    lineNumber: 484,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                lineNumber: 472,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                        lineNumber: 408,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-shift-block-tooltip": true,
                        className: "hidden group-hover:flex absolute right-0 top-full mt-1 left-1/2 -translate-x-1/2 min-w-[90px] w-max h-[45px] border-2 rounded-md list-none items-center z-[100] pointer-events-none after:content-[''] after:absolute after:left-1/2 after:top-[-8px] after:-translate-x-1/2 after:rotate-45 after:w-3 after:h-3 after:border-t-2 after:border-l-2 after:[border-top-color:var(--afterBorder)] after:[border-left-color:var(--afterBorder)]",
                        style: {
                            ['--afterBorder']: mainColor,
                            borderColor: mainColor
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between w-full px-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-bold m-0 rotate-180 whitespace-nowrap",
                                    style: {
                                        writingMode: 'vertical-rl'
                                    },
                                    children: block.startTime
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                    lineNumber: 498,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mb-0 font-bold leading-[17px] text-center",
                                    children: [
                                        doctorId ? displayName : block.label,
                                        doctorId !== 0 && block.label ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "block text-[10px]",
                                            children: block.label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                            lineNumber: 504,
                                            columnNumber: 17
                                        }, this) : null
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                    lineNumber: 501,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-bold m-0 rotate-180 whitespace-nowrap",
                                    style: {
                                        writingMode: 'vertical-rl'
                                    },
                                    children: block.endTime
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                                    lineNumber: 507,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                            lineNumber: 497,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                        lineNumber: 489,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                lineNumber: 407,
                columnNumber: 7
            }, this),
            !hideBottomStrip && (extra === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `h-3 ${stripRoundedClass} text-[10px] text-center leading-3 text-white font-bold tracking-[0.5px] mt-1.5${bottomStripClickable ? ' cursor-pointer' : ''}`,
                "data-doctor": "111",
                "data-testid": "shift-block-bottom",
                style: {
                    background: bottomPending ? pendingDoctorBottom.color : 'transparent',
                    border: extraDoc ? undefined : 'solid 1px #dcdcdc',
                    cursor: bottomHasClick ? 'pointer' : undefined,
                    opacity: dimBottom ? 0.35 : undefined
                },
                onClick: bottomHasClick ? (e)=>useSectionClick ? onSectionClick('bottom', e) : onClick(e) : undefined,
                children: bottomPending ? pendingDoctorBottom.shortName : null
            }, void 0, false, {
                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                lineNumber: 515,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `h-3 ${stripRoundedClass} text-[10px] text-center leading-3 text-white font-bold tracking-[0.5px] mt-1.5${bottomStripClickable ? ' cursor-pointer' : ''}`,
                "data-doctor": extra,
                "data-testid": "shift-block-bottom",
                style: {
                    background: extraDoc?.color ?? 'transparent',
                    cursor: bottomHasClick ? 'pointer' : undefined,
                    opacity: dimBottom ? 0.35 : undefined
                },
                onClick: bottomHasClick ? (e)=>useSectionClick ? onSectionClick('bottom', e) : onClick(e) : undefined,
                children: (extraDoc?.shortName ?? '').trim() || (extraDoc?.name ?? '').slice(0, 3).toUpperCase() || `#${extra}`
            }, void 0, false, {
                fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
                lineNumber: 530,
                columnNumber: 11
            }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ShiftBlock/ShiftBlock.tsx",
        lineNumber: 337,
        columnNumber: 5
    }, this);
}
_s(ShiftBlock, "fXjJT7kFPQLWSfFj/0hCUGCnOy0=");
_c = ShiftBlock;
var _c;
__turbopack_context__.k.register(_c, "ShiftBlock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/button.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$button$2f$Button$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@base-ui/react/esm/button/Button.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [client] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["cva"])("group/button inline-flex shrink-0 items-center justify-center rounded-lg border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
            outline: "border-border bg-background hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 aria-expanded:bg-secondary aria-expanded:text-secondary-foreground",
            ghost: "hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:hover:bg-muted/50",
            destructive: "bg-destructive/10 text-destructive hover:bg-destructive/20 focus-visible:border-destructive/40 focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:hover:bg-destructive/30 dark:focus-visible:ring-destructive/40",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-8 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
            xs: "h-6 gap-1 rounded-[min(var(--radius-md),10px)] px-2 text-xs in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
            sm: "h-7 gap-1 rounded-[min(var(--radius-md),12px)] px-2.5 text-[0.8rem] in-data-[slot=button-group]:rounded-lg has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3.5",
            lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-3 has-data-[icon=inline-start]:pl-3",
            icon: "size-8",
            "icon-xs": "size-6 rounded-[min(var(--radius-md),10px)] in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3",
            "icon-sm": "size-7 rounded-[min(var(--radius-md),12px)] in-data-[slot=button-group]:rounded-lg",
            "icon-lg": "size-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button({ className, variant = "default", size = "default", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$base$2d$ui$2f$react$2f$esm$2f$button$2f$Button$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Button"], {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 50,
        columnNumber: 5
    }, this);
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/monthpicker.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MonthPicker",
    ()=>MonthPicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const MONTHS = [
    [
        {
            number: 0,
            name: "Jan"
        },
        {
            number: 1,
            name: "Feb"
        },
        {
            number: 2,
            name: "Mar"
        },
        {
            number: 3,
            name: "Apr"
        }
    ],
    [
        {
            number: 4,
            name: "May"
        },
        {
            number: 5,
            name: "Jun"
        },
        {
            number: 6,
            name: "Jul"
        },
        {
            number: 7,
            name: "Aug"
        }
    ],
    [
        {
            number: 8,
            name: "Sep"
        },
        {
            number: 9,
            name: "Oct"
        },
        {
            number: 10,
            name: "Nov"
        },
        {
            number: 11,
            name: "Dec"
        }
    ]
];
function MonthPicker({ onMonthSelect, selectedMonth, minDate, maxDate, disabledDates, callbacks, onYearBackward, onYearForward, variant, className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])("min-w-[200px] w-[280px] p-3", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MonthCal, {
                    onMonthSelect: onMonthSelect,
                    callbacks: callbacks,
                    selectedMonth: selectedMonth,
                    onYearBackward: onYearBackward,
                    onYearForward: onYearForward,
                    variant: variant,
                    minDate: minDate,
                    maxDate: maxDate,
                    disabledDates: disabledDates
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/monthpicker.tsx",
                    lineNumber: 73,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/monthpicker.tsx",
                lineNumber: 72,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ui/monthpicker.tsx",
            lineNumber: 71,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/monthpicker.tsx",
        lineNumber: 70,
        columnNumber: 9
    }, this);
}
_c = MonthPicker;
function MonthCal({ selectedMonth, onMonthSelect, callbacks, variant, minDate, maxDate, disabledDates, onYearBackward, onYearForward }) {
    _s();
    const [year, setYear] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"](selectedMonth?.getFullYear() ?? new Date().getFullYear());
    const [month, setMonth] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"](selectedMonth?.getMonth() ?? new Date().getMonth());
    const [menuYear, setMenuYear] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"](year);
    if (minDate && maxDate && minDate > maxDate) minDate = maxDate;
    const disabledDatesMapped = disabledDates?.map((d)=>{
        return {
            year: d.getFullYear(),
            month: d.getMonth()
        };
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center pt-1 relative items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm font-medium",
                        children: callbacks?.yearLabel ? callbacks?.yearLabel(menuYear) : menuYear
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/monthpicker.tsx",
                        lineNumber: 104,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-x-1 flex items-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setMenuYear(menuYear - 1);
                                    if (onYearBackward) onYearBackward();
                                },
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
                                    variant: variant?.chevrons ?? "outline"
                                }), "inline-flex items-center justify-center h-7 w-7 p-0 absolute left-1"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                    className: "opacity-50 h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/monthpicker.tsx",
                                    lineNumber: 113,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/monthpicker.tsx",
                                lineNumber: 106,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    setMenuYear(menuYear + 1);
                                    if (onYearForward) onYearForward();
                                },
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
                                    variant: variant?.chevrons ?? "outline"
                                }), "inline-flex items-center justify-center h-7 w-7 p-0 absolute right-1"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    className: "opacity-50 h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ui/monthpicker.tsx",
                                    lineNumber: 122,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/monthpicker.tsx",
                                lineNumber: 115,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/monthpicker.tsx",
                        lineNumber: 105,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ui/monthpicker.tsx",
                lineNumber: 103,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                className: "w-full border-collapse space-y-1",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                    children: MONTHS.map((monthRow, a)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                            className: "flex w-full mt-2",
                            children: monthRow.map((m)=>{
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                    className: "h-10 w-1/4 text-center text-sm p-0 relative [&:has([aria-selected].day-range-end)]:rounded-r-md [&:has([aria-selected].day-outside)]:bg-accent/50 [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setMonth(m.number);
                                            setYear(menuYear);
                                            if (onMonthSelect) onMonthSelect(new Date(menuYear, m.number));
                                        },
                                        disabled: (maxDate ? menuYear > maxDate?.getFullYear() || menuYear == maxDate?.getFullYear() && m.number > maxDate.getMonth() : false) || (minDate ? menuYear < minDate?.getFullYear() || menuYear == minDate?.getFullYear() && m.number < minDate.getMonth() : false) || (disabledDatesMapped ? disabledDatesMapped?.some((d)=>d.year == menuYear && d.month == m.number) : false),
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["buttonVariants"])({
                                            variant: month == m.number && menuYear == year ? variant?.calendar?.selected ?? "default" : variant?.calendar?.main ?? "ghost"
                                        }), "h-full w-full p-0 font-normal aria-selected:opacity-100"),
                                        children: callbacks?.monthLabel ? callbacks.monthLabel(m) : m.name
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ui/monthpicker.tsx",
                                        lineNumber: 137,
                                        columnNumber: 45
                                    }, this)
                                }, m.number, false, {
                                    fileName: "[project]/src/components/ui/monthpicker.tsx",
                                    lineNumber: 133,
                                    columnNumber: 41
                                }, this);
                            })
                        }, "row-" + a, false, {
                            fileName: "[project]/src/components/ui/monthpicker.tsx",
                            lineNumber: 130,
                            columnNumber: 29
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/monthpicker.tsx",
                    lineNumber: 127,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/monthpicker.tsx",
                lineNumber: 126,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true);
}
_s(MonthCal, "M1zTZcjk+tzxc/L8BK9d18Dy8Tw=");
_c1 = MonthCal;
MonthPicker.displayName = "MonthPicker";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "MonthPicker");
__turbopack_context__.k.register(_c1, "MonthCal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/CalandarGrid/MonthNavigation.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MonthNavigation",
    ()=>MonthNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/calendarUtils.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$monthpicker$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/monthpicker.tsx [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function formatMonthYear(m, y) {
    const label = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["MONTH_SHORT"][m];
    const capitalized = label.charAt(0).toUpperCase() + label.slice(1);
    return `${capitalized} ${y}`;
}
const ArrowLeft = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: "w-4 h-4 shrink-0",
        viewBox: "0 0 16 16",
        fill: "currentColor",
        "aria-hidden": true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fillRule: "evenodd",
            d: "M9.78 4.22a.75.75 0 0 1 0 1.06L6.84 8l2.94 2.72a.75.75 0 1 1-1.04 1.08l-3.5-3.25a.75.75 0 0 1 0-1.08l3.5-3.25a.75.75 0 0 1 1.04 1.06Z",
            clipRule: "evenodd"
        }, void 0, false, {
            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
            lineNumber: 13,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = ArrowLeft;
const ArrowRight = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: "w-4 h-4 shrink-0",
        viewBox: "0 0 16 16",
        fill: "currentColor",
        "aria-hidden": true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fillRule: "evenodd",
            d: "M6.22 4.22a.75.75 0 0 1 1.06 0l3.5 3.25a.75.75 0 0 1 0 1.08l-3.5 3.25a.75.75 0 0 1-1.04-1.08L9.16 8 6.22 5.28a.75.75 0 0 1 0-1.06Z",
            clipRule: "evenodd"
        }, void 0, false, {
            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
            lineNumber: 19,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c1 = ArrowRight;
function MonthNavigation({ month, year, onSelectMonth }) {
    _s();
    const [pickerOpen, setPickerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pickerWrapperRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MonthNavigation.useEffect": ()=>{
            if (!pickerOpen) return;
            const handleClickOutside = {
                "MonthNavigation.useEffect.handleClickOutside": (event)=>{
                    if (pickerWrapperRef.current && !pickerWrapperRef.current.contains(event.target)) {
                        setPickerOpen(false);
                    }
                }
            }["MonthNavigation.useEffect.handleClickOutside"];
            document.addEventListener('mousedown', handleClickOutside);
            return ({
                "MonthNavigation.useEffect": ()=>document.removeEventListener('mousedown', handleClickOutside)
            })["MonthNavigation.useEffect"];
        }
    }["MonthNavigation.useEffect"], [
        pickerOpen
    ]);
    const prevMonth = (offset)=>{
        const d = new Date(year, month, 1);
        d.setMonth(d.getMonth() - offset);
        return {
            month: d.getMonth(),
            year: d.getFullYear()
        };
    };
    const nextMonth = (offset)=>{
        const d = new Date(year, month, 1);
        d.setMonth(d.getMonth() + offset);
        return {
            month: d.getMonth(),
            year: d.getFullYear()
        };
    };
    const navItems = [
        prevMonth(4),
        prevMonth(3),
        prevMonth(2),
        prevMonth(1)
    ];
    const nextItems = [
        nextMonth(1),
        nextMonth(2),
        nextMonth(3),
        nextMonth(4)
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-center min-w-0",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
            className: "flex items-center min-w-0",
            "aria-label": "Maandnavigatie",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "list-none flex flex-wrap items-center justify-center gap-y-2 gap-x-4 p-0 m-0",
                children: [
                    navItems.map(({ month: m, year: y })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "list-none p-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "bg-transparent border-none py-1 font-inherit text-gray-500 font-normal underline underline-offset-2 decoration-gray-300 cursor-pointer transition-colors duration-150 hover:text-gray-700",
                                onClick: ()=>onSelectMonth(m, y),
                                "aria-label": `Ga naar ${formatMonthYear(m, y)}`,
                                children: formatMonthYear(m, y)
                            }, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                lineNumber: 74,
                                columnNumber: 15
                            }, this)
                        }, `${y}-${m}`, false, {
                            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                            lineNumber: 73,
                            columnNumber: 13
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "list-none p-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "bg-transparent border-none py-1 px-2 cursor-pointer text-gray-800 flex items-center justify-center hover:opacity-80 transition-opacity",
                            onClick: ()=>{
                                const p = prevMonth(1);
                                onSelectMonth(p.month, p.year);
                            },
                            "aria-label": "Vorige maand",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ArrowLeft, {}, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                lineNumber: 94,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "list-none p-0 relative",
                        ref: pickerWrapperRef,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setPickerOpen((open)=>!open),
                                className: "font-bold text-gray-800 text-[1.05em] px-1 no-underline bg-transparent border-none cursor-pointer hover:opacity-80 transition-opacity",
                                "data-month": month,
                                "data-year": year,
                                "aria-label": "Kies maand en jaar",
                                "aria-expanded": pickerOpen,
                                "aria-haspopup": "dialog",
                                children: formatMonthYear(month, year)
                            }, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this),
                            pickerOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-full left-1/2 -translate-x-1/2 mt-1 z-50 bg-white rounded-lg border border-gray-200 shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$monthpicker$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["MonthPicker"], {
                                    selectedMonth: new Date(year, month, 1),
                                    onMonthSelect: (date)=>{
                                        onSelectMonth(date.getMonth(), date.getFullYear());
                                        setPickerOpen(false);
                                    },
                                    callbacks: {
                                        monthLabel: (m)=>{
                                            const name = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["MONTH_SHORT"][m.number];
                                            return name.charAt(0).toUpperCase() + name.slice(1);
                                        }
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                    lineNumber: 112,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                lineNumber: 111,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                        lineNumber: 97,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "list-none p-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            className: "bg-transparent border-none py-1 px-2 cursor-pointer text-gray-800 flex items-center justify-center hover:opacity-80 transition-opacity",
                            onClick: ()=>{
                                const n = nextMonth(1);
                                onSelectMonth(n.month, n.year);
                            },
                            "aria-label": "Volgende maand",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ArrowRight, {}, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                lineNumber: 138,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                            lineNumber: 129,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                        lineNumber: 128,
                        columnNumber: 11
                    }, this),
                    nextItems.map(({ month: m, year: y })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "list-none p-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: "bg-transparent border-none py-1 font-inherit text-gray-500 font-normal underline underline-offset-2 decoration-gray-300 cursor-pointer transition-colors duration-150 hover:text-gray-700",
                                onClick: ()=>onSelectMonth(m, y),
                                "aria-label": `Ga naar ${formatMonthYear(m, y)}`,
                                children: formatMonthYear(m, y)
                            }, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                                lineNumber: 143,
                                columnNumber: 15
                            }, this)
                        }, `${y}-${m}`, false, {
                            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                            lineNumber: 142,
                            columnNumber: 13
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
                lineNumber: 71,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
            lineNumber: 70,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/CalandarGrid/MonthNavigation.tsx",
        lineNumber: 69,
        columnNumber: 5
    }, this);
}
_s(MonthNavigation, "ULW25RfpSSV4l6aiM+tZsZfEzEo=");
_c2 = MonthNavigation;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ArrowLeft");
__turbopack_context__.k.register(_c1, "ArrowRight");
__turbopack_context__.k.register(_c2, "MonthNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/CalandarGrid/CalendarGrid.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CalendarGrid",
    ()=>CalendarGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/voorkeuren.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/calendarUtils.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShiftBlock$2f$ShiftBlock$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ShiftBlock/ShiftBlock.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CalandarGrid$2f$MonthNavigation$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CalandarGrid/MonthNavigation.tsx [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
/** Width of the right-hand column that shows waarneemgroep names per row (when multiple rows). */ const ROW_LABEL_WIDTH = 140;
/** Pad number to two digits for HH:MM. */ function pad2(n) {
    return n.toString().padStart(2, '0');
}
/**
 * Returns blocks that overlap the given calendar day, with the segment of each shift
 * that falls within that day (start/end as "HH:MM" in that day).
 * Used for overnight and multi-day shifts so they render in every day they span.
 */ function getBlocksWithSegmentsForDay(blocks, day, month0, year) {
    const dayStart = new Date(year, month0, day, 0, 0, 0, 0).getTime();
    const dayEnd = new Date(year, month0, day, 23, 59, 59, 999).getTime();
    const result = [];
    for (const block of blocks){
        const startStr = String(block.currentDate).replace(' ', 'T');
        const endStr = String(block.nextDate).replace(' ', 'T');
        const shiftStart = new Date(startStr).getTime();
        const shiftEnd = new Date(endStr).getTime();
        if (Number.isNaN(shiftStart) || Number.isNaN(shiftEnd)) continue;
        if (shiftEnd <= dayStart || shiftStart > dayEnd) continue;
        const segmentStartMs = Math.max(shiftStart, dayStart);
        const segmentEndMs = Math.min(shiftEnd, dayEnd);
        const segStart = new Date(segmentStartMs);
        const segEnd = new Date(segmentEndMs);
        const segmentStartTime = `${pad2(segStart.getHours())}:${pad2(segStart.getMinutes())}`;
        const segmentEndTime = segEnd.getHours() === 23 && segEnd.getMinutes() === 59 ? '24:00' : `${pad2(segEnd.getHours())}:${pad2(segEnd.getMinutes())}`;
        result.push({
            block,
            segmentStartTime,
            segmentEndTime
        });
    }
    return result;
}
/** Returns true if the block's shift interval overlaps the given calendar day. */ function blockOverlapsDay(block, day, month0, year) {
    const dayStart = new Date(year, month0, day, 0, 0, 0, 0).getTime();
    const dayEnd = new Date(year, month0, day, 23, 59, 59, 999).getTime();
    const startStr = String(block.currentDate).replace(' ', 'T');
    const endStr = String(block.nextDate).replace(' ', 'T');
    const shiftStart = new Date(startStr).getTime();
    const shiftEnd = new Date(endStr).getTime();
    if (Number.isNaN(shiftStart) || Number.isNaN(shiftEnd)) return false;
    return shiftEnd > dayStart && shiftStart <= dayEnd;
}
/** Previous calendar date (day - 1, handling month/year boundaries). */ function getPrevDate(day, month0, year) {
    const d = new Date(year, month0, day);
    d.setDate(d.getDate() - 1);
    return {
        day: d.getDate(),
        month0: d.getMonth(),
        year: d.getFullYear()
    };
}
/** Next calendar date (day + 1, handling month/year boundaries). */ function getNextDate(day, month0, year) {
    const d = new Date(year, month0, day);
    d.setDate(d.getDate() + 1);
    return {
        day: d.getDate(),
        month0: d.getMonth(),
        year: d.getFullYear()
    };
}
/**
 * Computes the voorkeur layout for an entire week row.
 *
 * Lane assignment is done GLOBALLY per user across all voorkeuren for the whole
 * week (not per day). This guarantees that an overnight voorkeur always occupies
 * the same lane on both the starting day and the ending day, so it appears as a
 * visually continuous bar across the midnight boundary.
 *
 * segmentEndTime boundary fix: uses `endMs >= dayEndMs` to emit '24:00' instead
 * of checking getHours() === 23, which fails when dayEndMs is midnight (00:00).
 */ function computeWeekVoorkeurLayout(voorkeuren, weekDates) {
    const DAY_MS = 24 * 60 * 60 * 1000;
    // Determine the time range covered by this week row.
    const firstRange = weekDates[0];
    const lastRange = weekDates[weekDates.length - 1];
    const weekStartMs = new Date(firstRange.Year, firstRange.Month, firstRange.Day, 0, 0, 0, 0).getTime();
    const weekEndMs = new Date(lastRange.Year, lastRange.Month, lastRange.Day, 0, 0, 0, 0).getTime() + DAY_MS;
    // Filter voorkeuren that overlap this week at all.
    const weekVks = voorkeuren.filter((vk)=>vk.van * 1000 < weekEndMs && vk.tot * 1000 > weekStartMs);
    // Group by user across the full week.
    const byUser = new Map();
    for (const vk of weekVks){
        if (vk.iddeelnemer == null) continue;
        if (!byUser.has(vk.iddeelnemer)) byUser.set(vk.iddeelnemer, []);
        byUser.get(vk.iddeelnemer).push(vk);
    }
    // Global lane assignment per user: each voorkeur gets a fixed lane index that
    // is consistent across ALL days it spans (no per-day re-assignment).
    const userInitials = new Map();
    const userMaxLanes = new Map();
    const vkToLane = new Map();
    for (const [userId, vks] of byUser){
        const d = vks[0].deelnemer;
        userInitials.set(userId, ((d?.voornaam?.[0] ?? '') + (d?.achternaam?.[0] ?? '')).toUpperCase());
        const sorted = [
            ...vks
        ].sort((a, b)=>a.van - b.van);
        // laneContents tracks which vks are assigned to each lane, for conflict checking.
        const laneContents = new Map();
        for (const vk of sorted){
            for(let laneIdx = 0;; laneIdx++){
                const existing = laneContents.get(laneIdx) ?? [];
                // Different-type temporal overlap → conflict, try next lane.
                const hasConflict = existing.some((ex)=>ex.type !== vk.type && ex.van * 1000 < vk.tot * 1000 && ex.tot * 1000 > vk.van * 1000);
                if (!hasConflict) {
                    if (!laneContents.has(laneIdx)) laneContents.set(laneIdx, []);
                    laneContents.get(laneIdx).push(vk);
                    vkToLane.set(vk, laneIdx);
                    break;
                }
            }
        }
        userMaxLanes.set(userId, laneContents.size);
    }
    // Build per-day lane data using the globally assigned lane indices.
    const p2 = (n)=>n.toString().padStart(2, '0');
    const byDayRaw = new Map();
    for (const range of weekDates){
        const day = range.Day;
        const month0 = range.Month;
        const year = range.Year;
        const dateKey = `${day}-${range.Month + 1}-${year}`;
        const dayStartMs = new Date(year, month0, day, 0, 0, 0, 0).getTime();
        const dayEndMs = dayStartMs + DAY_MS; // = midnight of the next day
        const dayMap = new Map();
        for (const [userId, vks] of byUser){
            const numLanes = userMaxLanes.get(userId) ?? 1;
            const lanes = Array.from({
                length: numLanes
            }, ()=>[]);
            for (const vk of vks){
                if (vk.van * 1000 >= dayEndMs || vk.tot * 1000 <= dayStartMs) continue;
                const laneIdx = vkToLane.get(vk) ?? 0;
                const startMs = Math.max(vk.van * 1000, dayStartMs);
                const endMs = Math.min(vk.tot * 1000, dayEndMs);
                const segStart = new Date(startMs);
                const segEnd = new Date(endMs);
                lanes[laneIdx].push({
                    voorkeur: vk,
                    segmentStartTime: `${p2(segStart.getHours())}:${p2(segStart.getMinutes())}`,
                    // endMs === dayEndMs means the segment reaches midnight: emit '24:00'.
                    // (segEnd.getHours() would be 0 here, not 23, so the old hours-check was wrong.)
                    segmentEndTime: endMs >= dayEndMs ? '24:00' : `${p2(segEnd.getHours())}:${p2(segEnd.getMinutes())}`,
                    continuesFromPrev: vk.van * 1000 < dayStartMs,
                    continuesToNext: vk.tot * 1000 > dayEndMs
                });
            }
            dayMap.set(userId, lanes);
        }
        byDayRaw.set(dateKey, dayMap);
    }
    // Build stable user slot order (sorted by userId for consistency across re-renders).
    const users = Array.from(userInitials.keys()).sort((a, b)=>a - b).map((userId)=>({
            userId,
            initials: userInitials.get(userId),
            numLanes: userMaxLanes.get(userId) ?? 1
        }));
    // Convert to indexed arrays matching the users order.
    const byDayIndexed = new Map();
    for (const [dateKey, dayMap] of byDayRaw){
        byDayIndexed.set(dateKey, users.map((u)=>dayMap.get(u.userId) ?? []));
    }
    return {
        users,
        byDay: byDayIndexed
    };
}
function voorkeurToShiftBlockView(vk) {
    const d = vk.deelnemer;
    const vanDate = new Date(vk.van * 1000);
    const totDate = new Date(vk.tot * 1000);
    const p2 = (n)=>n.toString().padStart(2, '0');
    const fmtDate = (dt)=>`${dt.getFullYear()}-${p2(dt.getMonth() + 1)}-${p2(dt.getDate())} ${p2(dt.getHours())}:${p2(dt.getMinutes())}:00`;
    const initials = ((d?.voornaam?.[0] ?? '') + (d?.achternaam?.[0] ?? '')).toUpperCase();
    const fullName = [
        d?.voornaam,
        d?.achternaam
    ].filter(Boolean).join(' ');
    return {
        id: vk.id ?? 0,
        day: vanDate.getDate(),
        month: vanDate.getMonth(),
        year: vanDate.getFullYear(),
        van: vk.van,
        tot: vk.tot,
        currentDate: fmtDate(vanDate),
        nextDate: fmtDate(totDate),
        startTime: `${p2(vanDate.getHours())}:${p2(vanDate.getMinutes())}`,
        endTime: `${p2(totDate.getHours())}:${p2(totDate.getMinutes())}`,
        label: '',
        middle: d ? {
            id: d.id ?? 0,
            name: fullName,
            shortName: initials,
            color: d.color ?? '#888888'
        } : null,
        top: null,
        bottom: null,
        assignedPreferenceCode: String(vk.type ?? '')
    };
}
function CalendarGrid({ shiftBlocks, rows, viewMonth, viewYear, onShiftClick, onSectionShiftClick, plannerDoctorPreferenceMap, hideTopStrip, hideBottomStrip, onShiftDelete, vakanties, onViewMonthChange, pendingInsert, pendingDelete, getChipByCode = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getChipByCode"], showPreferences = true, voorkeuren }) {
    _s();
    const vakantieList = vakanties ?? [];
    /** Normalize to rows: use rows when provided, else single row from shiftBlocks. */ const gridRows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CalendarGrid.useMemo[gridRows]": ()=>{
            if (rows?.length) return rows;
            const blocks = shiftBlocks ?? [];
            return [
                {
                    id: 0,
                    shiftBlocks: blocks
                }
            ];
        }
    }["CalendarGrid.useMemo[gridRows]"], [
        rows,
        shiftBlocks
    ]);
    const month0 = viewMonth; // viewMonth is 0-based (matches Rooster/Date); API is called with month+1 elsewhere
    let totalWeek = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["monthWeekCount"])(viewYear, month0);
    let currentMonthStartWeek = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getWeek"])(new Date(viewYear, month0, 1));
    let displayYear = viewYear;
    if (currentMonthStartWeek === 52) {
        displayYear -= 1;
        totalWeek += 1;
    }
    const weekRows = [];
    for(let i = 0; i < totalWeek; i++){
        const dates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getDateRangeOfWeek"])(currentMonthStartWeek, displayYear);
        weekRows.push({
            weekNo: currentMonthStartWeek,
            year: displayYear,
            dates
        });
        currentMonthStartWeek += 1;
    }
    const today = new Date();
    const todayDay = today.getDate();
    const todayMonth = today.getMonth() + 1;
    const todayYear = today.getFullYear();
    const vakantieByDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CalendarGrid.useMemo[vakantieByDate]": ()=>{
            const map = new Map();
            for (const v of vakantieList){
                const parts1 = v.current_date.split(/[-/]/);
                const parts2 = v.next_date.split(/[-/]/);
                const d1 = parts1.length >= 3 ? new Date(Number(parts1[0]), Number(parts1[1]) - 1, Number(parts1[2])) : new Date(v.current_date);
                const d2 = parts2.length >= 3 ? new Date(Number(parts2[0]), Number(parts2[1]) - 1, Number(parts2[2])) : new Date(v.next_date);
                const diff = Math.round((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
                for(let i = 0; i <= diff; i++){
                    const d = new Date(d1);
                    d.setDate(d.getDate() + i);
                    const key = `${d.getDate()}-${d.getMonth() + 1}-${d.getFullYear()}`;
                    if (!map.has(key)) map.set(key, []);
                    map.get(key).push(v.naam);
                }
            }
            return map;
        }
    }["CalendarGrid.useMemo[vakantieByDate]"], [
        vakantieList
    ]);
    const weekdays = [
        'Maandag',
        'Dinsdag',
        'Woensdag',
        'Donderdag',
        'Vrijdag',
        'Zaterdag',
        'Zondag'
    ];
    const content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full flex",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-[60px]"
                    }, void 0, false, {
                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                        lineNumber: 421,
                        columnNumber: 9
                    }, this),
                    weekdays.map((dayLabel)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "min-w-[100px] flex-1 h-[20px] mb-2 pl-2 text-base font-bold text-[#292727]",
                            children: dayLabel
                        }, dayLabel, false, {
                            fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                            lineNumber: 423,
                            columnNumber: 11
                        }, this)),
                    gridRows.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "shrink-0",
                        style: {
                            width: ROW_LABEL_WIDTH
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                        lineNumber: 430,
                        columnNumber: 33
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                lineNumber: 420,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full mx-auto",
                "data-tooltip": "Chip Active",
                children: weekRows.map(({ weekNo, year: weekYear, dates })=>{
                    const weekInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$calendarUtils$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getWeekNumber"])(dates[0].Date);
                    // Compute voorkeur layout once per week row so all 7 days share the same
                    // user order and lane counts → consistent row heights across the week.
                    const weekVoorkeurLayout = voorkeuren && voorkeuren.length > 0 ? computeWeekVoorkeurLayout(voorkeuren, dates) : null;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex w-full items-center justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-[60px] shrink-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-[30px] -rotate-90 text-base font-bold text-[#c1c1c1] whitespace-nowrap",
                                    children: [
                                        "Week ",
                                        weekInfo.week
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                    lineNumber: 446,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                lineNumber: 445,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-1 min-w-0 relative border border-[#979797] rounded-[13px] mb-2.5",
                                children: dates.map((range)=>{
                                    const rangeDay = range.Day;
                                    const rangeMonth1 = range.Month + 1;
                                    const rangeYear = range.Year;
                                    const dateKey = `${rangeDay}-${rangeMonth1}-${rangeYear}`;
                                    const isToday = rangeDay === todayDay && rangeMonth1 === todayMonth && rangeYear === todayYear;
                                    const vacationLabels = vakantieByDate.get(dateKey) ?? [];
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-[100px] flex-1 min-h-[110px] p-0 border-r border-[#c4c4c4] first:rounded-l-[13px] last:rounded-r-[13px] last:border-r-0 last:border-0 overflow-visible flex flex-col",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[#a0a0a0] text-[25px] my-0 mx-[5px] ml-2.5 flex items-center justify-between leading-none [&>span]:text-sm [&>span]:font-semibold [&>span]:tracking-[0.5px] [&>span]:text-[#c5c5c5]",
                                                "data-day-month-year": dateKey,
                                                style: isToday ? {
                                                    color: 'white',
                                                    backgroundColor: 'green',
                                                    fontWeight: 'bold',
                                                    width: '30px'
                                                } : undefined,
                                                children: [
                                                    rangeDay,
                                                    vacationLabels.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] text-green-600",
                                                        children: vacationLabels.join(', ')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                        lineNumber: 487,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                lineNumber: 471,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-1 flex-col gap-1.5 min-h-0",
                                                children: gridRows.map((row)=>{
                                                    const blocksWithSegments = getBlocksWithSegmentsForDay(row.shiftBlocks, rangeDay, range.Month, rangeYear);
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center relative min-h-[80px] m-0",
                                                        "data-block": row.id,
                                                        "data-row-name": row.name,
                                                        children: blocksWithSegments.map(({ block, segmentStartTime, segmentEndTime }, blockIndex)=>{
                                                            const prev = getPrevDate(rangeDay, range.Month, rangeYear);
                                                            const next = getNextDate(rangeDay, range.Month, rangeYear);
                                                            const continuesFromPrev = blockOverlapsDay(block, prev.day, prev.month0, prev.year);
                                                            const continuesToNext = blockOverlapsDay(block, next.day, next.month0, next.year);
                                                            const blockKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["shiftKeyFromBlock"])(block);
                                                            const isPendingDelete = pendingDelete?.has(blockKey);
                                                            const pendingCode = pendingInsert?.get(blockKey);
                                                            // Planner preference preview overrides block's own preference
                                                            const plannerChip = plannerDoctorPreferenceMap?.get(`${block.van}_${block.tot}`);
                                                            const preferenceChip = plannerChip ?? (isPendingDelete ? undefined : pendingCode ? getChipByCode(pendingCode) : block.assignedPreferenceCode ? getChipByCode(block.assignedPreferenceCode) : undefined);
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShiftBlock$2f$ShiftBlock$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["ShiftBlock"], {
                                                                block: block,
                                                                day: rangeDay,
                                                                month: range.Month,
                                                                year: rangeYear,
                                                                segmentStartTime: segmentStartTime,
                                                                segmentEndTime: segmentEndTime,
                                                                continuesFromPrev: continuesFromPrev,
                                                                continuesToNext: continuesToNext,
                                                                hideTopStrip: hideTopStrip,
                                                                hideBottomStrip: hideBottomStrip,
                                                                showEmptyTopStripBorder: onSectionShiftClick != null,
                                                                showEmptyBottomStripBorder: onSectionShiftClick != null,
                                                                onDelete: onShiftDelete ? ()=>onShiftDelete(block) : undefined,
                                                                onClick: onShiftClick ? (e)=>{
                                                                    const rect = e.currentTarget.getBoundingClientRect();
                                                                    onShiftClick(block, {
                                                                        top: rect.top + window.scrollY,
                                                                        left: rect.left + window.scrollX
                                                                    });
                                                                } : undefined,
                                                                onSectionClick: onSectionShiftClick ? (section)=>onSectionShiftClick(block, section) : undefined,
                                                                preferenceChip: preferenceChip ?? null
                                                            }, `${block.id}-${block.van}-${block.tot}-${dateKey}-${blockIndex}`, false, {
                                                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                                lineNumber: 529,
                                                                columnNumber: 35
                                                            }, this);
                                                        })
                                                    }, row.id, false, {
                                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                        lineNumber: 503,
                                                        columnNumber: 29
                                                    }, this);
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                lineNumber: 493,
                                                columnNumber: 23
                                            }, this),
                                            (showPreferences || weekVoorkeurLayout) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-2 border-t border-[#979797]",
                                                "aria-label": "preferences row",
                                                children: weekVoorkeurLayout && weekVoorkeurLayout.users.length > 0 ? // Per-user band: same structure for every day in the week.
                                                weekVoorkeurLayout.users.map((slot, slotIdx)=>{
                                                    const dayLanes = weekVoorkeurLayout.byDay.get(dateKey)?.[slotIdx] ?? [];
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mb-px",
                                                        children: Array.from({
                                                            length: slot.numLanes
                                                        }).map((_, laneIdx)=>{
                                                            const lane = dayLanes[laneIdx] ?? [];
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "relative",
                                                                style: {
                                                                    height: 22
                                                                },
                                                                children: lane.map(({ voorkeur, segmentStartTime, segmentEndTime, continuesFromPrev, continuesToNext })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ShiftBlock$2f$ShiftBlock$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["ShiftBlock"], {
                                                                        block: voorkeurToShiftBlockView(voorkeur),
                                                                        day: rangeDay,
                                                                        month: range.Month,
                                                                        year: rangeYear,
                                                                        hideTopStrip: true,
                                                                        hideBottomStrip: true,
                                                                        middleHeight: 20,
                                                                        disableActiveHighlight: true,
                                                                        segmentStartTime: segmentStartTime,
                                                                        segmentEndTime: segmentEndTime,
                                                                        continuesFromPrev: continuesFromPrev,
                                                                        continuesToNext: continuesToNext,
                                                                        preferenceChip: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["CHIP_DEFINITIONS"].find((c)=>c.code === String(voorkeur.type ?? '')) ?? null
                                                                    }, `vk-${voorkeur.id ?? `${voorkeur.iddeelnemer}_${voorkeur.idwaarneemgroep ?? 0}_${voorkeur.type}`}-${voorkeur.van}-${voorkeur.tot}`, false, {
                                                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                                        lineNumber: 589,
                                                                        columnNumber: 43
                                                                    }, this))
                                                            }, laneIdx, false, {
                                                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                                lineNumber: 587,
                                                                columnNumber: 39
                                                            }, this);
                                                        })
                                                    }, slot.userId, false, {
                                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                        lineNumber: 582,
                                                        columnNumber: 33
                                                    }, this);
                                                }) : // No voorkeuren this week: render empty placeholder for showPreferences pages.
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "min-h-[80px]"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                    lineNumber: 616,
                                                    columnNumber: 29
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                lineNumber: 576,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, dateKey, true, {
                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                        lineNumber: 466,
                                        columnNumber: 21
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                lineNumber: 451,
                                columnNumber: 15
                            }, this),
                            gridRows.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "shrink-0 pl-2 mb-2.5 flex flex-col",
                                style: {
                                    width: ROW_LABEL_WIDTH
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-h-[36px]",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                        lineNumber: 630,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-1 flex-col gap-1.5",
                                        children: gridRows.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center min-h-[80px] m-0 text-sm text-[#292727]",
                                                children: row.name ?? `Waarneemgroep ${row.id}`
                                            }, row.id, false, {
                                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                                lineNumber: 633,
                                                columnNumber: 23
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                        lineNumber: 631,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                                lineNumber: 626,
                                columnNumber: 17
                            }, this)
                        ]
                    }, `${weekNo}-${weekYear}`, true, {
                        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                        lineNumber: 443,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                lineNumber: 433,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            onViewMonthChange && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `mb-4 ml-[60px]${gridRows.length > 2 ? ' mr-[140px]' : ''}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CalandarGrid$2f$MonthNavigation$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["MonthNavigation"], {
                    month: viewMonth,
                    year: viewYear,
                    onSelectMonth: onViewMonthChange
                }, void 0, false, {
                    fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                    lineNumber: 659,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
                lineNumber: 656,
                columnNumber: 9
            }, this),
            content
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/CalandarGrid/CalendarGrid.tsx",
        lineNumber: 654,
        columnNumber: 5
    }, this);
}
_s(CalendarGrid, "3xKwlx+5pOK8bdN7u6GB6vCaB2Q=");
_c = CalendarGrid;
var _c;
__turbopack_context__.k.register(_c, "CalendarGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/CalandarGrid/CalendarGridWithNavState.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CalendarGridWithNavState",
    ()=>CalendarGridWithNavState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CalandarGrid$2f$CalendarGrid$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CalandarGrid/CalendarGrid.tsx [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function CalendarGridWithNavState({ rows, shiftBlocks, initialViewMonth = 2, initialViewYear = 2025, viewMonth: controlledViewMonth, viewYear: controlledViewYear, onViewMonthChange, hideTopStrip, hideBottomStrip, onShiftClick, pendingInsert, pendingDelete, getChipByCode, showPreferences, voorkeuren, onSectionShiftClick, plannerDoctorPreferenceMap, onShiftDelete }) {
    _s();
    const [internalViewMonth, setInternalViewMonth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(initialViewMonth);
    const [internalViewYear, setInternalViewYear] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(initialViewYear);
    const isControlled = controlledViewMonth !== undefined && controlledViewYear !== undefined && onViewMonthChange !== undefined;
    const viewMonth = isControlled ? controlledViewMonth : internalViewMonth;
    const viewYear = isControlled ? controlledViewYear : internalViewYear;
    const handleViewMonthChange = (month, year)=>{
        if (isControlled) {
            onViewMonthChange(month, year);
        } else {
            setInternalViewMonth(month);
            setInternalViewYear(year);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CalandarGrid$2f$CalendarGrid$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CalendarGrid"], {
        rows: rows,
        shiftBlocks: shiftBlocks,
        viewMonth: viewMonth,
        viewYear: viewYear,
        onViewMonthChange: handleViewMonthChange,
        hideTopStrip: hideTopStrip,
        hideBottomStrip: hideBottomStrip,
        onShiftClick: onShiftClick,
        pendingInsert: pendingInsert,
        pendingDelete: pendingDelete,
        getChipByCode: getChipByCode,
        showPreferences: showPreferences,
        voorkeuren: voorkeuren,
        onSectionShiftClick: onSectionShiftClick,
        plannerDoctorPreferenceMap: plannerDoctorPreferenceMap,
        onShiftDelete: onShiftDelete
    }, void 0, false, {
        fileName: "[project]/src/components/CalandarGrid/CalendarGridWithNavState.tsx",
        lineNumber: 99,
        columnNumber: 5
    }, this);
}
_s(CalendarGridWithNavState, "gq2DfoSwt/W+LuLxcU0B3Hin+a8=");
_c = CalendarGridWithNavState;
var _c;
__turbopack_context__.k.register(_c, "CalendarGridWithNavState");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/voorkeuren/ChipSelector.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CHIP_STYLE",
    ()=>CHIP_STYLE,
    "ChipSelector",
    ()=>ChipSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/briefcase.js [client] (ecmascript) <export default as Briefcase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/graduation-cap.js [client] (ecmascript) <export default as GraduationCap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tree$2d$palm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TreePalm$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/tree-palm.js [client] (ecmascript) <export default as TreePalm>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/voorkeuren.ts [client] (ecmascript)");
'use client';
;
;
;
const WEGHALEN_CODE = '1014';
const CHIP_STYLE = {
    '3': {
        backgroundColor: '#22c55e',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"],
        iconColor: 'white'
    },
    '2': {
        backgroundColor: '#eab308',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"],
        iconColor: 'white'
    },
    '9': {
        backgroundColor: '#ef4444',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tree$2d$palm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TreePalm$3e$__["TreePalm"],
        iconColor: 'white'
    },
    '10': {
        backgroundColor: '#a855f7',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__["GraduationCap"],
        iconColor: 'white'
    },
    '1014': {
        backgroundColor: '#94a3b8',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"],
        iconColor: 'white'
    },
    '5001': {
        backgroundColor: '#64748b',
        Icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Briefcase$3e$__["Briefcase"],
        iconColor: 'white'
    }
};
function ChipSelector({ selectedChipCode, onSelectChip }) {
    function handleClick(chip) {
        onSelectChip(selectedChipCode === chip.code ? null : chip.code);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-2",
        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["CHIP_DEFINITIONS"].map((chip)=>{
            const isSelected = selectedChipCode === chip.code;
            const style = CHIP_STYLE[chip.code];
            const IconComponent = style?.Icon;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "aria-label": chip.label,
                        "aria-pressed": isSelected,
                        "data-testid": `chip-${chip.code}`,
                        onClick: ()=>handleClick(chip),
                        className: `
                flex h-9 w-9 shrink-0 items-center justify-center rounded-md border-2 transition-colors
                focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2
                ${style ? '' : isSelected ? 'border-primary bg-primary/10 ring-2 ring-primary/30' : 'border-muted-foreground/30 bg-muted/50 hover:border-muted-foreground/60 hover:bg-muted'}
              `,
                        style: style ? {
                            backgroundColor: style.backgroundColor,
                            borderColor: isSelected ? 'var(--primary)' : 'rgba(0,0,0,0.2)',
                            ...isSelected ? {
                                boxShadow: '0 0 0 2px var(--primary)'
                            } : {}
                        } : undefined,
                        children: IconComponent ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(IconComponent, {
                            className: "h-4 w-4 shrink-0",
                            style: style ? {
                                color: style.iconColor
                            } : undefined,
                            "aria-hidden": true
                        }, void 0, false, {
                            fileName: "[project]/src/components/voorkeuren/ChipSelector.tsx",
                            lineNumber: 67,
                            columnNumber: 17
                        }, this) : null
                    }, void 0, false, {
                        fileName: "[project]/src/components/voorkeuren/ChipSelector.tsx",
                        lineNumber: 40,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm font-medium text-foreground",
                        children: chip.label
                    }, void 0, false, {
                        fileName: "[project]/src/components/voorkeuren/ChipSelector.tsx",
                        lineNumber: 74,
                        columnNumber: 13
                    }, this)
                ]
            }, chip.code, true, {
                fileName: "[project]/src/components/voorkeuren/ChipSelector.tsx",
                lineNumber: 39,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/src/components/voorkeuren/ChipSelector.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c = ChipSelector;
var _c;
__turbopack_context__.k.register(_c, "ChipSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useDienstenSchedule.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dienstenToShiftBlocks",
    ()=>dienstenToShiftBlocks,
    "dienstenToShiftBlocksFromParticipant",
    ()=>dienstenToShiftBlocksFromParticipant,
    "groupShiftBlocksByWaarneemgroep",
    ()=>groupShiftBlocksByWaarneemgroep,
    "useDienstenSchedule",
    ()=>useDienstenSchedule,
    "withWaarneemgroepNames",
    ()=>withWaarneemgroepNames
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function formatTwoDigits(n) {
    return n.toString().padStart(2, '0');
}
/** True if [aVan, aTot] and [bVan, bTot] overlap (half-open-style boundary check matches PHP shift overlap). */ function intervalsOverlap(aVan, aTot, bVan, bTot) {
    return aVan < bTot && aTot > bVan;
}
function toDoctorInfo(dienst) {
    const d = dienst.diensten_deelnemers;
    if (!d) return null;
    const fullName = `${d.voornaam} ${d.achternaam}`.trim();
    const shortName = (d.voornaam?.[0] ?? '').toUpperCase() + (d.achternaam?.[0] ?? '').toUpperCase();
    return {
        id: d.id,
        name: fullName || `Doctor ${d.id}`,
        shortName: shortName || `#${d.id}`,
        color: d.color || '#c686fd'
    };
}
function dienstenToShiftBlocksFromParticipant(response) {
    if (!response?.data?.diensten?.length) return [];
    const blocks = [];
    for (const dienst of response.data.diensten){
        const start = new Date(dienst.van * 1000);
        const end = new Date(dienst.tot * 1000);
        const day = start.getDate();
        const month0 = start.getMonth();
        const year = start.getFullYear();
        const startTime = `${formatTwoDigits(start.getHours())}:${formatTwoDigits(start.getMinutes())}`;
        const endTime = `${formatTwoDigits(end.getHours())}:${formatTwoDigits(end.getMinutes())}`;
        const currentDate = `${start.getFullYear()}-${formatTwoDigits(start.getMonth() + 1)}-${formatTwoDigits(start.getDate())} ${startTime}:00`;
        const nextDate = `${end.getFullYear()}-${formatTwoDigits(end.getMonth() + 1)}-${formatTwoDigits(end.getDate())} ${endTime}:00`;
        const middle = toDoctorInfo(dienst);
        blocks.push({
            id: dienst.id,
            day,
            month: month0,
            year,
            van: dienst.van,
            tot: dienst.tot,
            startTime,
            endTime,
            currentDate,
            nextDate,
            middle: middle ?? null,
            top: null,
            bottom: null,
            idwaarneemgroep: dienst.idwaarneemgroep
        });
    }
    return blocks;
}
function dienstenToShiftBlocks(response) {
    if (!response?.data?.diensten?.length) return [];
    // 0/4/6=Standaard (legacy PHP uses 4 and 6 alongside 0), 1=slot, 5=Achterwacht, 9=Extra Dokter, 11=deprecated (old Next) still merged into bottom
    const relevantTypes = new Set([
        0,
        1,
        4,
        5,
        6,
        9,
        11
    ]);
    const byKey = new Map();
    for (const dienst of response.data.diensten){
        if (!relevantTypes.has(dienst.type)) continue;
        const start = new Date(dienst.van * 1000);
        const day = start.getDate();
        const month0 = start.getMonth(); // 0-based
        const year = start.getFullYear();
        const wg = dienst.idwaarneemgroep ?? '';
        const key = `${day}-${month0}-${year}-${dienst.van}-${dienst.tot}-${wg}`;
        const existing = byKey.get(key);
        if (existing) {
            if (dienst.type === 1 && !existing.base) {
                existing.base = dienst;
            }
            existing.items.push(dienst);
        } else {
            byKey.set(key, {
                base: dienst.type === 1 ? dienst : null,
                items: [
                    dienst
                ]
            });
        }
    }
    const blocks = [];
    for (const { base, items } of byKey.values()){
        if (!base) {
            continue;
        }
        const start = new Date(base.van * 1000);
        const end = new Date(base.tot * 1000);
        const day = start.getDate();
        const month0 = start.getMonth();
        const year = start.getFullYear();
        const startTime = `${formatTwoDigits(start.getHours())}:${formatTwoDigits(start.getMinutes())}`;
        const endTime = `${formatTwoDigits(end.getHours())}:${formatTwoDigits(end.getMinutes())}`;
        const currentDate = `${start.getFullYear()}-${formatTwoDigits(start.getMonth() + 1)}-${formatTwoDigits(start.getDate())} ${startTime}:00`;
        const nextDate = `${end.getFullYear()}-${formatTwoDigits(end.getMonth() + 1)}-${formatTwoDigits(end.getDate())} ${endTime}:00`;
        let middle = null;
        let top = null;
        let bottom = null;
        for (const dienst of items){
            switch(dienst.type){
                case 0:
                case 4:
                case 6:
                    {
                        if (!middle) middle = toDoctorInfo(dienst);
                        break;
                    }
                case 5:
                    {
                        if (!top) top = toDoctorInfo(dienst);
                        break;
                    }
                case 9:
                case 11:
                    {
                        // 9 = Extra Dokter (legacy PHP); 11 kept only so older rows from this app still render
                        if (!bottom) bottom = toDoctorInfo(dienst);
                        break;
                    }
                default:
                    break;
            }
        }
        // Standaard assignment may be one wide row (types 0/4/6) overlapping this type=1 chunk only — not in `items`.
        if (!middle) {
            const wg = base.idwaarneemgroep ?? 0;
            for (const dienst of response.data.diensten){
                const t = dienst.type;
                if (t !== 0 && t !== 4 && t !== 6) continue;
                if ((dienst.idwaarneemgroep ?? 0) !== wg) continue;
                if (!intervalsOverlap(dienst.van, dienst.tot, base.van, base.tot)) continue;
                const d = toDoctorInfo(dienst);
                if (d) {
                    middle = d;
                    break;
                }
            }
        }
        blocks.push({
            id: base.id,
            day,
            month: month0,
            year,
            van: base.van,
            tot: base.tot,
            startTime,
            endTime,
            currentDate,
            nextDate,
            middle,
            top,
            bottom,
            idwaarneemgroep: base.idwaarneemgroep
        });
    }
    return blocks;
}
function groupShiftBlocksByWaarneemgroep(blocks) {
    const byWg = new Map();
    for (const block of blocks){
        const wg = block.idwaarneemgroep ?? 0;
        if (!byWg.has(wg)) byWg.set(wg, []);
        byWg.get(wg).push(block);
    }
    const sortedIds = Array.from(byWg.keys()).sort((a, b)=>a - b);
    return sortedIds.map((id)=>({
            id,
            name: id === 0 ? 'Overig' : undefined,
            shiftBlocks: byWg.get(id)
        }));
}
function withWaarneemgroepNames(rows, waarneemgroepen) {
    if (!waarneemgroepen?.length) return rows;
    return rows.map((row)=>{
        const wg = waarneemgroepen.find((w)=>w.id != null && w.id === row.id);
        const name = wg?.naam ?? row.name ?? (row.id === 0 ? 'Overig' : `Waarneemgroep ${row.id}`);
        return {
            ...row,
            name
        };
    });
}
function useDienstenSchedule(response) {
    _s();
    const shiftBlocks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDienstenSchedule.useMemo[shiftBlocks]": ()=>dienstenToShiftBlocks(response)
    }["useDienstenSchedule.useMemo[shiftBlocks]"], [
        response
    ]);
    return {
        shiftBlocks
    };
}
_s(useDienstenSchedule, "kkFOWm5sH/z4YkC3h/X4ygKR5z8=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/cached-fetch.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cachedGetJson",
    ()=>cachedGetJson,
    "clearCacheByPrefix",
    ()=>clearCacheByPrefix
]);
/**
 * In-memory cache that deduplicates in-flight GET requests and reuses
 * recent responses for a short TTL. Reduces duplicate calls from React
 * Strict Mode double-mount and from multiple components requesting the same URL.
 */ const CACHE_TTL_MS = 2000;
const responseCache = new Map();
const inFlight = new Map();
function pruneCache() {
    const now = Date.now();
    for (const [key, entry] of responseCache.entries()){
        if (now - entry.timestamp > CACHE_TTL_MS) responseCache.delete(key);
    }
}
function clearCacheByPrefix(prefix) {
    for (const key of responseCache.keys()){
        if (key.startsWith(prefix)) responseCache.delete(key);
    }
}
async function cachedGetJson(url) {
    const cached = responseCache.get(url);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
        return cached.data;
    }
    const existing = inFlight.get(url);
    if (existing) {
        return existing;
    }
    const promise = fetch(url, {
        credentials: 'include'
    }).then((res)=>res.json()).then((data)=>{
        responseCache.set(url, {
            data,
            timestamp: Date.now()
        });
        inFlight.delete(url);
        pruneCache();
        return data;
    }).catch((err)=>{
        inFlight.delete(url);
        throw err;
    });
    inFlight.set(url, promise);
    return promise;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useDienstenSubscription.ts [client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDienstenSubscription",
    ()=>useDienstenSubscription
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cached$2d$fetch$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cached-fetch.ts [client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
/** API returns diensten with van/tot as number and diensten_deelnemers; normalize to our type. */ function toDienstenResponse(diensten) {
    const list = diensten.map((d)=>({
            id: d.id ?? 0,
            iddeelnemer: d.iddeelnemer ?? 0,
            van: d.van,
            tot: d.tot,
            type: d.type ?? 0,
            idwaarneemgroep: d.idwaarneemgroep ?? undefined,
            diensten_deelnemers: d.diensten_deelnemers ? {
                id: d.diensten_deelnemers.id ?? 0,
                voornaam: d.diensten_deelnemers.voornaam ?? '',
                achternaam: d.diensten_deelnemers.achternaam ?? '',
                color: d.diensten_deelnemers.color ?? ''
            } : null
        }));
    return {
        data: {
            diensten: list
        }
    };
}
function useDienstenSubscription(vanGte, totLte, idwaarneemgroepen, typeIn, iddeelnemer, _refreshKey) {
    _s();
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDienstenSubscription.useEffect": ()=>{
            if (idwaarneemgroepen.length === 0) {
                setData(null);
                setLoading(false);
                return;
            }
            if (iddeelnemer !== undefined && (iddeelnemer === null || iddeelnemer <= 0)) {
                setData({
                    data: {
                        diensten: []
                    }
                });
                setLoading(false);
                return;
            }
            setLoading(true);
            setError(null);
            let cancelled = false;
            const params = new URLSearchParams({
                vanGte: String(vanGte),
                totLte: String(totLte),
                idwaarneemgroepIn: idwaarneemgroepen.join(',')
            });
            if (typeIn != null && typeIn.length > 0) {
                params.set('typeIn', typeIn.join(','));
            }
            if (iddeelnemer != null && iddeelnemer > 0) {
                params.set('iddeelnemer', String(iddeelnemer));
            }
            const url = `/api/diensten?${params}`;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cached$2d$fetch$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cachedGetJson"])(url).then({
                "useDienstenSubscription.useEffect": (json)=>{
                    if (cancelled) return;
                    if (json.error) {
                        setError(json.error);
                        setData(null);
                    } else if (Array.isArray(json.diensten)) {
                        setData(toDienstenResponse(json.diensten));
                        setError(null);
                    } else {
                        setData({
                            data: {
                                diensten: []
                            }
                        });
                    }
                    setLoading(false);
                }
            }["useDienstenSubscription.useEffect"]).catch({
                "useDienstenSubscription.useEffect": (err)=>{
                    if (!cancelled) {
                        setError(err instanceof Error ? err.message : 'Failed to load diensten');
                        setData(null);
                        setLoading(false);
                    }
                }
            }["useDienstenSubscription.useEffect"]);
            return ({
                "useDienstenSubscription.useEffect": ()=>{
                    cancelled = true;
                }
            })["useDienstenSubscription.useEffect"];
        }
    }["useDienstenSubscription.useEffect"], [
        vanGte,
        totLte,
        idwaarneemgroepen.join(','),
        typeIn?.join(',') ?? '',
        iddeelnemer ?? '',
        _refreshKey ?? 0
    ]);
    return {
        data,
        error,
        loading
    };
}
_s(useDienstenSubscription, "cdnblwmK9QuMyYTkxGRQb1PLKRw=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/contexts/WaarneemgroepContext.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WaarneemgroepContext",
    ()=>WaarneemgroepContext,
    "WaarneemgroepProvider",
    ()=>WaarneemgroepProvider,
    "useWaarneemgroep",
    ()=>useWaarneemgroep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cached$2d$fetch$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cached-fetch.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const STORAGE_GROUP_ID_KEY = 'groupid';
function getStoredGroupId() {
    if (typeof localStorage === 'undefined') return null;
    const id = localStorage.getItem(STORAGE_GROUP_ID_KEY);
    return id && id.trim() !== '' ? id : null;
}
function toWaarneemgroepItem(row) {
    return {
        ID: row.id ?? 0,
        naam: row.naam ?? ''
    };
}
const WaarneemgroepContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useWaarneemgroep() {
    _s();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useContext"])(WaarneemgroepContext);
    if (!ctx) {
        throw new Error('useWaarneemgroep must be used within WaarneemgroepProvider');
    }
    return ctx;
}
_s(useWaarneemgroep, "/dMy7t63NXD4eYACoT93CePwGrg=");
function WaarneemgroepProvider({ children }) {
    _s1();
    const [waarneemgroepen, setWaarneemgroepen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeWaarneemgroepId, setActiveWaarneemgroepIdState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        "WaarneemgroepProvider.useState": ()=>getStoredGroupId()
    }["WaarneemgroepProvider.useState"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WaarneemgroepProvider.useEffect": ()=>{
            let cancelled = false;
            setLoading(true);
            setError(null);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cached$2d$fetch$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["cachedGetJson"])('/api/waarneemgroepen').then({
                "WaarneemgroepProvider.useEffect": (data)=>{
                    if (cancelled) return;
                    if (data.error) {
                        setError(data.error);
                        setWaarneemgroepen([]);
                    } else {
                        const list = (data.waarneemgroepen ?? []).map(toWaarneemgroepItem);
                        setWaarneemgroepen(list);
                    }
                    setLoading(false);
                }
            }["WaarneemgroepProvider.useEffect"]).catch({
                "WaarneemgroepProvider.useEffect": (err)=>{
                    if (!cancelled) {
                        setError(err instanceof Error ? err.message : 'Request failed');
                        setWaarneemgroepen([]);
                        setLoading(false);
                    }
                }
            }["WaarneemgroepProvider.useEffect"]);
            return ({
                "WaarneemgroepProvider.useEffect": ()=>{
                    cancelled = true;
                }
            })["WaarneemgroepProvider.useEffect"];
        }
    }["WaarneemgroepProvider.useEffect"], []);
    // Auto-select first waarneemgroep when none is stored (fresh session)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WaarneemgroepProvider.useEffect": ()=>{
            if (!activeWaarneemgroepId && waarneemgroepen.length > 0) {
                const firstId = String(waarneemgroepen[0].ID);
                localStorage.setItem(STORAGE_GROUP_ID_KEY, firstId);
                setActiveWaarneemgroepIdState(firstId);
            }
        }
    }["WaarneemgroepProvider.useEffect"], [
        activeWaarneemgroepId,
        waarneemgroepen
    ]);
    const setActiveWaarneemgroepId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WaarneemgroepProvider.useCallback[setActiveWaarneemgroepId]": (id)=>{
            if (id) {
                localStorage.setItem(STORAGE_GROUP_ID_KEY, id);
            }
            setActiveWaarneemgroepIdState(id);
        }
    }["WaarneemgroepProvider.useCallback[setActiveWaarneemgroepId]"], []);
    const activeWaarneemgroep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WaarneemgroepProvider.useMemo[activeWaarneemgroep]": ()=>{
            if (!activeWaarneemgroepId) return null;
            return waarneemgroepen.find({
                "WaarneemgroepProvider.useMemo[activeWaarneemgroep]": (wg)=>String(wg.ID) === activeWaarneemgroepId
            }["WaarneemgroepProvider.useMemo[activeWaarneemgroep]"]) ?? null;
        }
    }["WaarneemgroepProvider.useMemo[activeWaarneemgroep]"], [
        activeWaarneemgroepId,
        waarneemgroepen
    ]);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WaarneemgroepProvider.useMemo[value]": ()=>({
                waarneemgroepen,
                activeWaarneemgroepId,
                activeWaarneemgroep,
                setActiveWaarneemgroepId,
                loading,
                error
            })
    }["WaarneemgroepProvider.useMemo[value]"], [
        waarneemgroepen,
        activeWaarneemgroepId,
        activeWaarneemgroep,
        setActiveWaarneemgroepId,
        loading,
        error
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WaarneemgroepContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/WaarneemgroepContext.tsx",
        lineNumber: 136,
        columnNumber: 5
    }, this);
}
_s1(WaarneemgroepProvider, "6r5/fVM89sF8wluC2cKOvajoSLc=");
_c = WaarneemgroepProvider;
var _c;
__turbopack_context__.k.register(_c, "WaarneemgroepProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/pages/voorkeuren.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VoorkeurenPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$head$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/head.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-client.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CalandarGrid$2f$CalendarGridWithNavState$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CalandarGrid/CalendarGridWithNavState.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$voorkeuren$2f$ChipSelector$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/voorkeuren/ChipSelector.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSchedule$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useDienstenSchedule.ts [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSubscription$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useDienstenSubscription.ts [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WaarneemgroepContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/WaarneemgroepContext.tsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/types/voorkeuren.ts [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
const TWO_WEEKS_SECONDS = 14 * 24 * 60 * 60;
/** Unix seconds for start of first day of month (0-based), minus 2 weeks so adjacent visible days have data. */ function vanGteForMonth(viewMonth, viewYear) {
    return Math.floor(new Date(viewYear, viewMonth, 1, 0, 0, 0, 0).getTime() / 1000) - TWO_WEEKS_SECONDS;
}
/** Unix seconds for end of last day of month (23:59:59), plus 2 weeks so adjacent visible days have data. */ function totLteForMonth(viewMonth, viewYear) {
    return Math.floor(new Date(viewYear, viewMonth + 1, 0, 23, 59, 59, 999).getTime() / 1000) + TWO_WEEKS_SECONDS;
}
const WEGHALEN_CODE = '1014';
/** Type 1 = unassigned slot (empty shift block). */ const TYPE_UNASSIGNED_SLOT = 1;
/** Types for user preference rows (2, 3, 9, 10, 5001). */ const USER_DIENST_TYPES = [
    2,
    3,
    9,
    10,
    5001
];
function VoorkeurenPage() {
    _s();
    const { data: session } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["authClient"].useSession();
    const name = session?.user?.name ?? session?.user?.email ?? 'daar';
    const { activeWaarneemgroepId, activeWaarneemgroep, loading: waarneemgroepContextLoading, error: waarneemgroepContextError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WaarneemgroepContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["useWaarneemgroep"])();
    const now = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VoorkeurenPage.useMemo[now]": ()=>new Date()
    }["VoorkeurenPage.useMemo[now]"], []);
    const [viewMonth, setViewMonth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(now.getMonth());
    const [viewYear, setViewYear] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(now.getFullYear());
    const [selectedChipCode, setSelectedChipCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pendingInsert, setPendingInsert] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(new Map());
    const [pendingDelete, setPendingDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [preferenceApiError, setPreferenceApiError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    /** Block duplicate API calls: keys of slots that have a request in flight. */ const inFlightKeysRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(new Set());
    /** Cursor position for chip preview (only used when selectedChipCode is set). */ const [cursorPreview, setCursorPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    /** Only the selected waarneemgroep in the header (one at a time). */ const waarneemgroepIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VoorkeurenPage.useMemo[waarneemgroepIds]": ()=>{
            if (!activeWaarneemgroepId) return [];
            const id = Number(activeWaarneemgroepId);
            return Number.isNaN(id) ? [] : [
                id
            ];
        }
    }["VoorkeurenPage.useMemo[waarneemgroepIds]"], [
        activeWaarneemgroepId
    ]);
    const vanGte = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VoorkeurenPage.useMemo[vanGte]": ()=>vanGteForMonth(viewMonth, viewYear)
    }["VoorkeurenPage.useMemo[vanGte]"], [
        viewMonth,
        viewYear
    ]);
    const totLte = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VoorkeurenPage.useMemo[totLte]": ()=>totLteForMonth(viewMonth, viewYear)
    }["VoorkeurenPage.useMemo[totLte]"], [
        viewMonth,
        viewYear
    ]);
    const idDeelnemer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VoorkeurenPage.useMemo[idDeelnemer]": ()=>{
            const id = session?.user?.id;
            if (id == null) return null;
            const n = Number(id);
            return Number.isNaN(n) ? null : n;
        }
    }["VoorkeurenPage.useMemo[idDeelnemer]"], [
        session?.user?.id
    ]);
    /** Empty slots (type 1) for the calendar grid. */ const { data: type1Response, loading: type1Loading, error: type1Error } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSubscription$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDienstenSubscription"])(vanGte, totLte, waarneemgroepIds, [
        TYPE_UNASSIGNED_SLOT
    ]);
    /** User's assigned diensten (types 2, 3, 9, 10, 5001), one-time fetch at page load. */ const { data: userDienstenResponse, loading: userDienstenLoading, error: userDienstenError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSubscription$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDienstenSubscription"])(vanGte, totLte, waarneemgroepIds, [
        ...USER_DIENST_TYPES
    ], idDeelnemer ?? null);
    const rows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "VoorkeurenPage.useMemo[rows]": ()=>{
            const emptyBlocks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSchedule$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["dienstenToShiftBlocks"])(type1Response ?? null);
            const userBlocks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSchedule$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["dienstenToShiftBlocksFromParticipant"])(userDienstenResponse ?? null);
            const userBySlot = new Map();
            const typeBySlot = new Map();
            for (const b of userBlocks){
                const key = `${b.van}-${b.tot}-${b.idwaarneemgroep ?? ''}`;
                userBySlot.set(key, b.middle);
            }
            for (const d of userDienstenResponse?.data?.diensten ?? []){
                const key = `${d.van}-${d.tot}-${d.idwaarneemgroep ?? ''}`;
                typeBySlot.set(key, d.type);
            }
            const blocks = emptyBlocks.map({
                "VoorkeurenPage.useMemo[rows].blocks": (block)=>{
                    const key = `${block.van}-${block.tot}-${block.idwaarneemgroep ?? ''}`;
                    if (pendingDelete.has((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["shiftKeyFromBlock"])(block))) return block;
                    const assigned = userBySlot.get(key);
                    const type = typeBySlot.get(key);
                    if (assigned && type != null) {
                        return {
                            ...block,
                            middle: assigned,
                            assignedPreferenceCode: String(type)
                        };
                    }
                    if (assigned) {
                        return {
                            ...block,
                            middle: assigned
                        };
                    }
                    return block;
                }
            }["VoorkeurenPage.useMemo[rows].blocks"]);
            const grouped = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSchedule$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["groupShiftBlocksByWaarneemgroep"])(blocks);
            return grouped.map({
                "VoorkeurenPage.useMemo[rows]": (row)=>({
                        ...row,
                        name: activeWaarneemgroep?.naam ?? row.name
                    })
            }["VoorkeurenPage.useMemo[rows]"]);
        }
    }["VoorkeurenPage.useMemo[rows]"], [
        type1Response,
        userDienstenResponse,
        activeWaarneemgroep?.naam,
        pendingDelete
    ]);
    const loading = waarneemgroepContextLoading || waarneemgroepIds.length > 0 && (type1Loading || userDienstenLoading);
    const error = waarneemgroepContextError ?? type1Error ?? userDienstenError;
    const handleShiftClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VoorkeurenPage.useCallback[handleShiftClick]": async (block)=>{
            if (selectedChipCode === null) return;
            if (block.idwaarneemgroep == null) return;
            const key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["shiftKeyFromBlock"])(block);
            if (inFlightKeysRef.current.has(key)) return;
            inFlightKeysRef.current.add(key);
            const idwaarneemgroep = block.idwaarneemgroep;
            const action = selectedChipCode === WEGHALEN_CODE ? 'remove' : 'add';
            setPreferenceApiError(null);
            if (action === 'remove') {
                setPendingInsert({
                    "VoorkeurenPage.useCallback[handleShiftClick]": (prev)=>{
                        const next = new Map(prev);
                        next.delete(key);
                        return next;
                    }
                }["VoorkeurenPage.useCallback[handleShiftClick]"]);
                setPendingDelete({
                    "VoorkeurenPage.useCallback[handleShiftClick]": (prev)=>new Set(prev).add(key)
                }["VoorkeurenPage.useCallback[handleShiftClick]"]);
            } else {
                setPendingDelete({
                    "VoorkeurenPage.useCallback[handleShiftClick]": (prev)=>{
                        const next = new Set(prev);
                        next.delete(key);
                        return next;
                    }
                }["VoorkeurenPage.useCallback[handleShiftClick]"]);
                setPendingInsert({
                    "VoorkeurenPage.useCallback[handleShiftClick]": (prev)=>new Map(prev).set(key, selectedChipCode)
                }["VoorkeurenPage.useCallback[handleShiftClick]"]);
            }
            const body = {
                action,
                van: block.van,
                tot: block.tot,
                idwaarneemgroep,
                ...action === 'add' && {
                    type: Number(selectedChipCode)
                },
                currentDate: block.currentDate,
                nextDate: block.nextDate
            };
            const PREFERENCE_REQUEST_TIMEOUT_MS = 2000;
            const controller = new AbortController();
            const timeoutId = setTimeout({
                "VoorkeurenPage.useCallback[handleShiftClick].timeoutId": ()=>controller.abort()
            }["VoorkeurenPage.useCallback[handleShiftClick].timeoutId"], PREFERENCE_REQUEST_TIMEOUT_MS);
            function revertPending() {
                if (action === 'remove') {
                    setPendingDelete({
                        "VoorkeurenPage.useCallback[handleShiftClick].revertPending": (prev)=>{
                            const next = new Set(prev);
                            next.delete(key);
                            return next;
                        }
                    }["VoorkeurenPage.useCallback[handleShiftClick].revertPending"]);
                } else {
                    setPendingInsert({
                        "VoorkeurenPage.useCallback[handleShiftClick].revertPending": (prev)=>{
                            const next = new Map(prev);
                            next.delete(key);
                            return next;
                        }
                    }["VoorkeurenPage.useCallback[handleShiftClick].revertPending"]);
                }
            }
            function showFailure(reason) {
                setPreferenceApiError(reason);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["toast"].error('Voorkeur niet opgeslagen', {
                    description: reason
                });
            }
            try {
                const res = await fetch('/api/diensten/preference', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(body),
                    credentials: 'include',
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                const data = await res.json().catch({
                    "VoorkeurenPage.useCallback[handleShiftClick]": ()=>({})
                }["VoorkeurenPage.useCallback[handleShiftClick]"]);
                if (!res.ok) {
                    revertPending();
                    const message = typeof data?.error === 'string' ? data.error : 'Voorkeur opslaan mislukt.';
                    showFailure(message);
                }
            } catch (err) {
                clearTimeout(timeoutId);
                revertPending();
                const reason = err instanceof Error && err.name === 'AbortError' ? 'Verzoek duurde te lang. Probeer het opnieuw.' : err instanceof Error ? err.message : 'Voorkeur opslaan mislukt.';
                showFailure(reason);
            } finally{
                inFlightKeysRef.current.delete(key);
            }
        }
    }["VoorkeurenPage.useCallback[handleShiftClick]"], [
        selectedChipCode
    ]);
    const calendarGridRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VoorkeurenPage.useEffect": ()=>{
            if (!selectedChipCode) {
                setCursorPreview(null);
                return;
            }
            function onMove(e) {
                setCursorPreview({
                    x: e.clientX,
                    y: e.clientY
                });
            }
            function onLeave() {
                setCursorPreview(null);
            }
            function onKeyDown(e) {
                if (e.key === 'Escape') setSelectedChipCode(null);
            }
            function onPointerDown(e) {
                const el = calendarGridRef.current;
                if (!el || !el.contains(e.target)) setSelectedChipCode(null);
            }
            window.addEventListener('mousemove', onMove);
            window.addEventListener('mouseleave', onLeave);
            window.addEventListener('keydown', onKeyDown);
            document.addEventListener('pointerdown', onPointerDown);
            return ({
                "VoorkeurenPage.useEffect": ()=>{
                    window.removeEventListener('mousemove', onMove);
                    window.removeEventListener('mouseleave', onLeave);
                    window.removeEventListener('keydown', onKeyDown);
                    document.removeEventListener('pointerdown', onPointerDown);
                }
            })["VoorkeurenPage.useEffect"];
        }
    }["VoorkeurenPage.useEffect"], [
        selectedChipCode
    ]);
    const chipStyle = selectedChipCode ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$voorkeuren$2f$ChipSelector$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CHIP_STYLE"][selectedChipCode] : null;
    const CursorChipIcon = chipStyle?.Icon;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            cursorPreview && chipStyle && CursorChipIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "aria-hidden": true,
                className: "pointer-events-none fixed z-9999 flex h-9 w-9 items-center justify-center rounded-md border-2 border-primary shadow-lg",
                style: {
                    left: cursorPreview.x + 12,
                    top: cursorPreview.y + 12,
                    backgroundColor: chipStyle.backgroundColor,
                    borderColor: 'var(--primary)'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CursorChipIcon, {
                    className: "h-4 w-4 shrink-0",
                    style: {
                        color: chipStyle.iconColor
                    }
                }, void 0, false, {
                    fileName: "[project]/src/pages/voorkeuren.tsx",
                    lineNumber: 267,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/pages/voorkeuren.tsx",
                lineNumber: 257,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$head$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                    children: "Voorkeuren | Doktersdienst"
                }, void 0, false, {
                    fileName: "[project]/src/pages/voorkeuren.tsx",
                    lineNumber: 271,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/pages/voorkeuren.tsx",
                lineNumber: 270,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-[2000px] space-y-6 px-4 py-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Card"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        id: "voorkeuren-heading",
                                        className: "text-2xl font-semibold tracking-tight",
                                        children: "Voorkeuren"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/voorkeuren.tsx",
                                        lineNumber: 277,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/voorkeuren.tsx",
                                    lineNumber: 276,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                lineNumber: 275,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-muted-foreground",
                                    children: [
                                        "Openstaande diensten (type 1) voor de geselecteerde waarneemgroep; uw toegewezen diensten worden bij het laden opgehaald.",
                                        activeWaarneemgroep ? ` Huidige groep: ${activeWaarneemgroep.naam}.` : ' Selecteer een waarneemgroep in de header.',
                                        ' ',
                                        "Welkom, ",
                                        name,
                                        ". Selecteer een voorkeur en klik op een dienst in de kalender om deze toe te wijzen."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/pages/voorkeuren.tsx",
                                    lineNumber: 283,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                lineNumber: 282,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/voorkeuren.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-6 lg:flex-row",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Card"], {
                                className: "shrink-0 lg:w-[220px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                            className: "text-base",
                                            children: "Voorkeur kiezen"
                                        }, void 0, false, {
                                            fileName: "[project]/src/pages/voorkeuren.tsx",
                                            lineNumber: 293,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/voorkeuren.tsx",
                                        lineNumber: 292,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$voorkeuren$2f$ChipSelector$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["ChipSelector"], {
                                            selectedChipCode: selectedChipCode,
                                            onSelectChip: setSelectedChipCode
                                        }, void 0, false, {
                                            fileName: "[project]/src/pages/voorkeuren.tsx",
                                            lineNumber: 296,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/voorkeuren.tsx",
                                        lineNumber: 295,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                lineNumber: 291,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["Card"], {
                                className: "min-w-0 flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                            children: activeWaarneemgroep ? `Openstaande diensten – ${activeWaarneemgroep.naam}` : 'Openstaande diensten'
                                        }, void 0, false, {
                                            fileName: "[project]/src/pages/voorkeuren.tsx",
                                            lineNumber: 304,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/voorkeuren.tsx",
                                        lineNumber: 303,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                        children: [
                                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mb-4 text-destructive",
                                                role: "alert",
                                                children: error
                                            }, void 0, false, {
                                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                                lineNumber: 310,
                                                columnNumber: 17
                                            }, this),
                                            preferenceApiError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mb-4 text-destructive",
                                                role: "alert",
                                                children: preferenceApiError
                                            }, void 0, false, {
                                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                                lineNumber: 315,
                                                columnNumber: 17
                                            }, this),
                                            !activeWaarneemgroepId && !loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mb-4 text-muted-foreground",
                                                children: "Selecteer een waarneemgroep in de header om openstaande diensten te zien."
                                            }, void 0, false, {
                                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                                lineNumber: 320,
                                                columnNumber: 17
                                            }, this),
                                            loading && !type1Response && waarneemgroepIds.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mb-4 text-muted-foreground",
                                                children: "Voorkeuren laden…"
                                            }, void 0, false, {
                                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                                lineNumber: 325,
                                                columnNumber: 17
                                            }, this),
                                            selectedChipCode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mb-4 text-sm text-muted-foreground",
                                                children: "Geselecteerd: klik op een dienst in de kalender om deze voorkeur toe te wijzen."
                                            }, void 0, false, {
                                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                                lineNumber: 328,
                                                columnNumber: 17
                                            }, this),
                                            waarneemgroepIds.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                ref: calendarGridRef,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CalandarGrid$2f$CalendarGridWithNavState$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["CalendarGridWithNavState"], {
                                                    rows: rows,
                                                    initialViewMonth: now.getMonth(),
                                                    initialViewYear: now.getFullYear(),
                                                    viewMonth: viewMonth,
                                                    viewYear: viewYear,
                                                    onViewMonthChange: (month, year)=>{
                                                        setViewMonth(month);
                                                        setViewYear(year);
                                                    },
                                                    hideTopStrip: true,
                                                    hideBottomStrip: true,
                                                    onShiftClick: selectedChipCode ? (block)=>handleShiftClick(block) : undefined,
                                                    pendingInsert: pendingInsert,
                                                    pendingDelete: pendingDelete,
                                                    getChipByCode: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$types$2f$voorkeuren$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["getChipByCode"],
                                                    showPreferences: false
                                                }, void 0, false, {
                                                    fileName: "[project]/src/pages/voorkeuren.tsx",
                                                    lineNumber: 334,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                                lineNumber: 333,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/pages/voorkeuren.tsx",
                                        lineNumber: 308,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/pages/voorkeuren.tsx",
                                lineNumber: 302,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/voorkeuren.tsx",
                        lineNumber: 290,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/voorkeuren.tsx",
                lineNumber: 273,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(VoorkeurenPage, "Fz0pSjAJzBukF8z04lakdMG9uE4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$client$2e$ts__$5b$client$5d$__$28$ecmascript$29$__["authClient"].useSession,
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$WaarneemgroepContext$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["useWaarneemgroep"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSubscription$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDienstenSubscription"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useDienstenSubscription$2e$ts__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDienstenSubscription"]
    ];
});
_c = VoorkeurenPage;
var _c;
__turbopack_context__.k.register(_c, "VoorkeurenPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/voorkeuren.tsx [client] (ecmascript)\" } [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const PAGE_PATH = "/voorkeuren";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_context__.r("[project]/src/pages/voorkeuren.tsx [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}),
"[hmr-entry]/hmr-entry.js { ENTRY => \"[project]/src/pages/voorkeuren\" }", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.r("[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/voorkeuren.tsx [client] (ecmascript)\" } [client] (ecmascript)");
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__5ad33abd._.js.map