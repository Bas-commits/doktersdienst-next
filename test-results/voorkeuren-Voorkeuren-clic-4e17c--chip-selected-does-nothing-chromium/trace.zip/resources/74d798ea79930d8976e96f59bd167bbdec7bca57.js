(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_8066b03d._.js",
  "static/chunks/node_modules_next_dist_client_881bc7f7._.js",
  "static/chunks/node_modules_next_dist_75b597d7._.js",
  "static/chunks/node_modules_next_b8cbaf14._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_@base-ui_react_esm_92bffa37._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ab97e45._.js",
  "static/chunks/node_modules_ba722b4f._.js",
  "static/chunks/[root-of-the-server]__6fe0c653._.js"
],
    source: "entry"
});
