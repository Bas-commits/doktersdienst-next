self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/pages/index.js"
  ],
  "/login": [
    "static/chunks/pages/login.js"
  ],
  "/rooster-inzien": [
    "static/chunks/pages/rooster-inzien.js"
  ],
  "/rooster-maken-secretaris": [
    "static/chunks/pages/rooster-maken-secretaris.js"
  ],
  "/voorkeuren": [
    "static/chunks/pages/voorkeuren.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/artsen",
    "/api/auth/[...all]",
    "/api/deelnemers",
    "/api/deelnemers/color",
    "/api/deelnemers/groepen",
    "/api/deelnemers/registratie",
    "/api/diensten",
    "/api/diensten/assign",
    "/api/diensten/create",
    "/api/diensten/delete-shift",
    "/api/diensten/options",
    "/api/diensten/preference",
    "/api/diensten/preference.test",
    "/api/diensten/recurrence-info",
    "/api/diensten/voorkeuren",
    "/api/hello",
    "/api/mijn-gegevens",
    "/api/mijn-gegevens/lookup",
    "/api/regios",
    "/api/regios/[id]",
    "/api/vakanties",
    "/api/vakanties/[id]",
    "/api/waarneemgroep-gegevens",
    "/api/waarneemgroep-toevoegen",
    "/api/waarneemgroep-toevoegen/[id]",
    "/api/waarneemgroep-wijzigen",
    "/api/waarneemgroep-wijzigen/[id]",
    "/api/waarneemgroepen",
    "/dashboard",
    "/diensten-toevoegen",
    "/lijst-deelnemers",
    "/login",
    "/mijn-gegevens",
    "/overnames",
    "/regio-toevoegen",
    "/rollen-afmelden",
    "/rooster-inzien",
    "/rooster-inzien-dummy",
    "/rooster-maken-secretaris",
    "/signup",
    "/vakanties",
    "/voorkeuren",
    "/waarneemgroep-gegevens",
    "/waarneemgroep-toevoegen",
    "/waarneemgroep-wijzigen",
    "/waarneemgroepen"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()