(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ed66b523._.js",
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_9a2a7093._.js",
  "static/chunks/node_modules_next_dist_client_5a8a528e._.js",
  "static/chunks/node_modules_next_dist_75b597d7._.js",
  "static/chunks/node_modules_next_head_6b89d279.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ab97e45._.js",
  "static/chunks/node_modules_@base-ui_react_esm_bef5cc62._.js",
  "static/chunks/node_modules_135d2035._.js"
],
    source: "entry"
});
