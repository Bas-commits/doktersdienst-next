(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/next/router.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/router.js [client] (ecmascript)");
}),
"[project]/node_modules/next/head.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/head.js [client] (ecmascript)");
}),
"[project]/node_modules/next/link.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/link.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=node_modules_next_b8cbaf14._.js.map